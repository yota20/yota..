import React from 'react';
import { ActiveTab } from '../types';
import { sounds } from '../utils/audio';

interface BottomMobileNavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenWallet: () => void;
  onOpenProfile: () => void;
}

export const BottomMobileNavbar: React.FC<BottomMobileNavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenWallet,
  onOpenProfile,
}) => {
  return (
    <nav
      id="bottom-mobile-nav"
      className="fixed bottom-0 left-0 w-full z-50 md:hidden flex justify-around items-center p-3 bg-[#f7f9fb]/90 dark:bg-[#111416]/90 backdrop-blur-lg rounded-t-2xl border-t border-black/10 dark:border-white/10 shadow-[0_-10px_30px_rgba(0,0,0,0.15)] pb-5 select-none"
    >
      {/* Home */}
      <button
        onClick={() => {
          sounds.playClick();
          setActiveTab('discover');
        }}
        className={`flex flex-col items-center justify-center transition-all duration-150 cursor-pointer ${
          activeTab === 'discover'
            ? 'text-[#00677f] dark:text-[#00d2ff] scale-105 font-bold'
            : 'text-[#3c494e]/70 dark:text-[#bfc8cc]/70'
        }`}
      >
        <span
          className="material-symbols-outlined text-2xl"
          style={{ fontVariationSettings: activeTab === 'discover' ? "'FILL' 1" : "'FILL' 0" }}
        >
          grid_view
        </span>
        <span className="text-[10px] mt-0.5">خانه</span>
      </button>

      {/* Games */}
      <button
        onClick={() => {
          sounds.playClick();
          setActiveTab('games');
        }}
        className={`flex flex-col items-center justify-center transition-all duration-150 cursor-pointer ${
          activeTab === 'games'
            ? 'text-[#00677f] dark:text-[#00d2ff] scale-105 font-bold'
            : 'text-[#3c494e]/70 dark:text-[#bfc8cc]/70'
        }`}
      >
        <span
          className="material-symbols-outlined text-2xl"
          style={{ fontVariationSettings: activeTab === 'games' ? "'FILL' 1" : "'FILL' 0" }}
        >
          sports_esports
        </span>
        <span className="text-[10px] mt-0.5">بازی‌ها</span>
      </button>

      {/* Wallet */}
      <button
        onClick={() => {
          sounds.playCoin();
          onOpenWallet();
        }}
        className={`flex flex-col items-center justify-center transition-all duration-150 cursor-pointer ${
          activeTab === 'wallet'
            ? 'text-[#00677f] dark:text-[#00d2ff] scale-105 font-bold'
            : 'text-[#3c494e]/70 dark:text-[#bfc8cc]/70'
        }`}
      >
        <span className="material-symbols-outlined text-2xl">account_balance_wallet</span>
        <span className="text-[10px] mt-0.5">کیف پول</span>
      </button>

      {/* Profile */}
      <button
        onClick={() => {
          sounds.playClick();
          onOpenProfile();
        }}
        className="flex flex-col items-center justify-center text-[#3c494e]/70 dark:text-[#bfc8cc]/70 hover:text-[#00677f] dark:hover:text-[#00d2ff] transition-colors cursor-pointer"
      >
        <span className="material-symbols-outlined text-2xl">person</span>
        <span className="text-[10px] mt-0.5">پروفایل</span>
      </button>
    </nav>
  );
};
