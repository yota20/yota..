import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, UserProfile } from '../types';
import { sounds } from '../utils/audio';

interface LiveChatSidebarProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  user: UserProfile;
}

export const LiveChatSidebar: React.FC<LiveChatSidebarProps> = ({
  messages,
  onSendMessage,
  user,
}) => {
  const [inputText, setInputText] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [activeChannel, setActiveChannel] = useState<'general' | 'gaming' | 'trade'>('general');
  const chatScrollRef = useRef<HTMLDivElement>(null);

  const emojis = ['🔥', '🎮', '💎', '🏆', '🎲', '❤️', '🚀', '😎', '⚡', '✨', '👏', '🎯'];

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;

    sounds.playChatPing();
    onSendMessage(inputText.trim());
    setInputText('');
    setShowEmojiPicker(false);
  };

  const handleAddEmoji = (emoji: string) => {
    setInputText((prev) => prev + emoji);
  };

  const handleQuickDiceRoll = () => {
    const dice = Math.floor(Math.random() * 6) + 1;
    sounds.playDiceRoll();
    onSendMessage(`🎲 تاس انداختم و عدد ${dice} اومد!`);
    setShowAttachMenu(false);
  };

  const handleInviteToLudo = () => {
    sounds.playCoin();
    onSendMessage('🎮 بیاید مسابقه 4 نفره Neon Ludo Strike! اتاق #402 باز شد.');
    setShowAttachMenu(false);
  };

  return (
    <aside
      id="live-chat-sidebar"
      className="w-80 h-full hidden lg:flex flex-col bg-[#f7f9fb]/50 dark:bg-[#111416]/70 backdrop-blur-xl border border-black/10 dark:border-white/10 rounded-2xl overflow-hidden glass-panel shrink-0 select-none"
    >
      {/* Header */}
      <div className="p-3 border-b border-black/10 dark:border-white/10 flex justify-between items-center bg-black/5 dark:bg-black/30">
        <div className="flex items-center gap-2">
          <span className="material-symbols-outlined text-[18px] text-[#00677f] dark:text-[#00d2ff]">
            chat
          </span>
          <h3 className="font-bold text-sm text-[#191c1e] dark:text-white">چت عمومی سرور</h3>
        </div>

        {/* Channel Tabs / More menu */}
        <div className="flex items-center gap-1">
          <span className="text-[10px] bg-[#23a559]/20 text-[#23a559] px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[#23a559] animate-pulse"></span>
            ۲۴ آنلاین
          </span>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div
        ref={chatScrollRef}
        className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 text-sm hide-scrollbar"
      >
        <div className="text-center text-xs text-[#3c494e]/60 dark:text-[#bfc8cc]/60 my-1 bg-black/5 dark:bg-white/5 py-1 px-3 rounded-full self-center">
          به اتاق گفتگو خوش آمدید
        </div>

        {messages.map((msg) => {
          const isMe = msg.senderName === user.name;
          return (
            <div
              key={msg.id}
              className={`flex gap-3 group transition-all ${
                isMe ? 'bg-[#00677f]/5 dark:bg-[#00d2ff]/10 p-2 rounded-xl border border-[#00d2ff]/20' : ''
              }`}
            >
              <img
                className="w-8 h-8 rounded-full object-cover shrink-0 border border-white/40 shadow-sm"
                src={msg.senderAvatar}
                alt={msg.senderName}
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-baseline gap-2">
                  <span
                    className={`font-bold text-xs flex items-center gap-1 ${
                      msg.senderVip
                        ? 'text-[#bb00fc] dark:text-[#ecb2ff]'
                        : isMe
                        ? 'text-[#00677f] dark:text-[#00d2ff]'
                        : 'text-[#191c1e] dark:text-white'
                    }`}
                    style={msg.color ? { color: msg.color } : undefined}
                  >
                    {msg.senderVip && (
                      <span className="material-symbols-outlined text-[13px] text-[#bb00fc]">
                        diamond
                      </span>
                    )}
                    {msg.senderName}
                  </span>
                  <span className="text-[10px] text-[#3c494e]/50 dark:text-[#bfc8cc]/50">
                    {msg.time}
                  </span>
                </div>
                <p className="text-xs text-[#191c1e]/90 dark:text-[#e0e3e5] mt-0.5 break-words leading-relaxed">
                  {msg.text}
                </p>

                {/* Reactions */}
                {msg.reactions && Object.keys(msg.reactions).length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-1.5">
                    {Object.entries(msg.reactions).map(([emoji, count]) => (
                      <button
                        key={emoji}
                        onClick={() => {
                          sounds.playClick();
                          if (!msg.reactions) msg.reactions = {};
                          msg.reactions[emoji] = (msg.reactions[emoji] || 0) + 1;
                        }}
                        className="text-[11px] bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 px-1.5 py-0.5 rounded-md flex items-center gap-1 text-[#3c494e] dark:text-[#bfc8cc] transition-all cursor-pointer active:scale-95"
                      >
                        <span>{emoji}</span>
                        <span className="font-bold">{count}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Input Area */}
      <div className="p-3 bg-black/5 dark:bg-black/30 border-t border-black/10 dark:border-white/10 relative">
        {/* Quick Attach / Actions Menu */}
        {showAttachMenu && (
          <div className="absolute bottom-16 right-3 bg-white dark:bg-[#191c1e] p-2 rounded-xl shadow-xl border border-black/10 dark:border-white/10 z-30 flex flex-col gap-1 w-48 animate-slide-up">
            <button
              onClick={handleQuickDiceRoll}
              className="flex items-center gap-2 p-2 hover:bg-black/5 dark:hover:bg-white/5 rounded-lg text-xs font-semibold text-[#191c1e] dark:text-white text-right cursor-pointer"
            >
              <span className="material-symbols-outlined text-[#bb00fc] text-[18px]">casino</span>
              <span>تاس انداختن سریع</span>
            </button>
            <button
              onClick={handleInviteToLudo}
              className="flex items-center gap-2 p-2 hover:bg-black/5 dark:hover:bg-white/5 rounded-lg text-xs font-semibold text-[#191c1e] dark:text-white text-right cursor-pointer"
            >
              <span className="material-symbols-outlined text-[#00d2ff] text-[18px]">
                sports_esports
              </span>
              <span>دعوت به بازی Ludo</span>
            </button>
          </div>
        )}

        {/* Emoji Picker Popover */}
        {showEmojiPicker && (
          <div className="absolute bottom-16 left-3 bg-white dark:bg-[#191c1e] p-3 rounded-2xl shadow-2xl border border-black/10 dark:border-white/10 z-30 grid grid-cols-4 gap-2 w-52 animate-slide-up">
            {emojis.map((emoji) => (
              <button
                key={emoji}
                onClick={() => handleAddEmoji(emoji)}
                className="text-lg p-2 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 flex items-center justify-center transition-all hover:scale-125 cursor-pointer"
              >
                {emoji}
              </button>
            ))}
          </div>
        )}

        <form onSubmit={handleSend} className="flex items-center gap-2 bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-xl p-1.5 focus-within:border-[#00d2ff] transition-all">
          <button
            type="button"
            id="btn-chat-attach"
            onClick={() => {
              sounds.playClick();
              setShowAttachMenu(!showAttachMenu);
              setShowEmojiPicker(false);
            }}
            className="text-[#3c494e] dark:text-[#bfc8cc] hover:text-[#00677f] dark:hover:text-[#00d2ff] transition-colors p-1 rounded cursor-pointer"
            title="امکانات و فعالیت‌ها"
          >
            <span className="material-symbols-outlined text-[20px]">add_circle</span>
          </button>

          <input
            id="chat-input-field"
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="پیام بدهید..."
            className="flex-1 bg-transparent border-none text-xs md:text-sm focus:outline-none text-[#191c1e] dark:text-white placeholder:text-[#3c494e]/50 dark:placeholder:text-[#bfc8cc]/50"
          />

          <button
            type="button"
            id="btn-chat-emoji"
            onClick={() => {
              sounds.playClick();
              setShowEmojiPicker(!showEmojiPicker);
              setShowAttachMenu(false);
            }}
            className="text-[#3c494e] dark:text-[#bfc8cc] hover:text-[#9500ca] dark:hover:text-[#bb00fc] transition-colors p-1 rounded cursor-pointer"
            title="شکلک‌ها"
          >
            <span className="material-symbols-outlined text-[20px]">mood</span>
          </button>

          <button
            type="submit"
            className="p-1 rounded-lg text-[#00677f] dark:text-[#00d2ff] hover:bg-black/5 dark:hover:bg-white/10 transition-colors cursor-pointer"
            title="ارسال"
          >
            <span className="material-symbols-outlined text-[20px]">send</span>
          </button>
        </form>
      </div>
    </aside>
  );
};
