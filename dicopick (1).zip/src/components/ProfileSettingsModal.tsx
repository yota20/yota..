import React, { useState } from 'react';
import { UserProfile } from '../types';
import { sounds } from '../utils/audio';

interface ProfileSettingsModalProps {
  user: UserProfile;
  isOpen: boolean;
  onClose: () => void;
  onSaveProfile: (updated: Partial<UserProfile>) => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const ProfileSettingsModal: React.FC<ProfileSettingsModalProps> = ({
  user,
  isOpen,
  onClose,
  onSaveProfile,
  isDarkMode,
  onToggleTheme,
  soundEnabled,
  onToggleSound,
}) => {
  const [name, setName] = useState(user.name);
  const [statusText, setStatusText] = useState(user.statusText);
  const [bio, setBio] = useState(user.bio);
  const [selectedAvatar, setSelectedAvatar] = useState(user.avatar);

  if (!isOpen) return null;

  const avatars = [
    'https://lh3.googleusercontent.com/aida-public/AB6AXuC55ToRYeQqupVjkDGr3KFmy40GVV91EtoRfBg6fmPgLueVifmz3z7yEFiBEg9l3_JsXhHACaBjbql5_Vjvj9-TZ3pnCZ4Bm5Niu4alLLDQIFWgBotpzkjkGjyUWhqu92qt3fgo9ZL6Tu87Gq0UkBLFRWlKAq1kfM0_LhUHEhV7ruxzV1TDEHOvft-bo30cYqfN0H6TOdbR0hY2peGvEzaOkUWltTHOgCVukGovb2rb1ISzNCUzb3db',
    'https://lh3.googleusercontent.com/aida-public/AB6AXuDXFdfwzDl_nYbIDUrjoucCHg6iu0BA59WXeS7AvAnyGuJBN13rmrHJvnr_t0QF6rXORW8DO2yJrSp00H82tT8wGqfw-nBq4izuJUqUproaDEdAzzr3UYsOcvwXP2PHCS1_l1zdS2p8edgLSeaz18QFRvs8t1076syvg96wBCQ7of8_escATNPrVSCSTXpBmvgOB1qAkrZ7ED5hL4KotljwdLtJTp2tA5hnCjvwQbAFQHhLE0NFsDp2',
    'https://lh3.googleusercontent.com/aida-public/AB6AXuDUnjPJ4yuoYE7Pr6UTZccTf2tCMz1aPODGAhVb2wVe_u1Z1LU4hdIIlV03a7piXI2YWAtH3KGfsYdeOXf5GIbnxnEdP_idq2C1PHyJLc0uUwShzw8zwIWUsx8BPiNZjhvtkFnZnUdtXvIZ_K-pRaBlnfD19NLcivS1l8QfP9dHcXDLlRr7c69cLedvQTH0X8mSoXRDrSjVUNeFx2z7Jb1SqkCIR8LpG-JVx_vXxeNtC7TljP3IVvzp',
    'https://lh3.googleusercontent.com/aida-public/AB6AXuCIIHn6jp5CtBRFYA_avyKo-2sW_Hpet0x8G_33_CihDGXvfTXigmzYVO6a_fv4enOkwSAdsk1ZQPnLvxktnMEylC3WBJk2kjUPEx9plh96milQ07PF_XBEHfoMRg465cFdSPKhPlrTqvCXR6kBpGmvDefEgdPWGR7KSYkoKsu4yrowZK4ScbvyQjxSJjB7Ak2qMmNYhBiIMbXgSwW4WnLP3DhXscoT7hNbA2ekMSeZOzpe4CCxGQQp',
  ];

  const handleSave = () => {
    sounds.playCoin();
    onSaveProfile({
      name,
      statusText,
      bio,
      avatar: selectedAvatar,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#f7f9fb] dark:bg-[#191c1e] w-full max-w-lg rounded-3xl border border-white/40 dark:border-white/10 shadow-2xl p-6 flex flex-col gap-5 text-right animate-slide-up select-none">
        {/* Header */}
        <div className="flex justify-between items-center pb-3 border-b border-black/10 dark:border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#00677f] to-[#00d2ff] flex items-center justify-center text-white shadow-lg">
              <span className="material-symbols-outlined text-2xl">manage_accounts</span>
            </div>
            <div>
              <h2 className="font-extrabold text-lg text-[#191c1e] dark:text-white">
                تنظیمات حساب کاربری
              </h2>
              <p className="text-xs text-[#3c494e] dark:text-[#bfc8cc]">
                شخصی‌سازی آواتار، نام مستعار و وضعیت
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-black/5 dark:bg-white/10 hover:bg-black/10 text-on-surface flex items-center justify-center transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Avatars Grid */}
        <div className="flex flex-col gap-2">
          <label className="text-xs font-bold text-[#191c1e] dark:text-white">
            انتخاب آواتار متاورس:
          </label>
          <div className="flex gap-3">
            {avatars.map((av, idx) => (
              <button
                key={idx}
                onClick={() => {
                  sounds.playClick();
                  setSelectedAvatar(av);
                }}
                className={`w-14 h-14 rounded-2xl overflow-hidden border-2 transition-all cursor-pointer ${
                  selectedAvatar === av
                    ? 'border-[#00d2ff] ring-4 ring-[#00d2ff]/30 scale-105 shadow-lg'
                    : 'border-white/40 opacity-70 hover:opacity-100'
                }`}
              >
                <img className="w-full h-full object-cover" src={av} alt={`Avatar ${idx}`} />
              </button>
            ))}
          </div>
        </div>

        {/* Name Input */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-bold text-[#191c1e] dark:text-white">نام نمایشی:</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-xl p-2.5 text-sm text-[#191c1e] dark:text-white focus:outline-none focus:border-[#00d2ff]"
          />
        </div>

        {/* Status Message Input */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-bold text-[#191c1e] dark:text-white">پیام وضعیت:</label>
          <input
            type="text"
            value={statusText}
            onChange={(e) => setStatusText(e.target.value)}
            className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-xl p-2.5 text-sm text-[#191c1e] dark:text-white focus:outline-none focus:border-[#00d2ff]"
          />
        </div>

        {/* Quick Preferences Toggles */}
        <div className="grid grid-cols-2 gap-3 pt-2">
          <button
            type="button"
            onClick={onToggleTheme}
            className="p-3 rounded-xl bg-black/5 dark:bg-white/5 hover:bg-black/10 flex items-center justify-between text-xs font-bold text-[#191c1e] dark:text-white cursor-pointer"
          >
            <span>حالت تم تاریک</span>
            <span className="material-symbols-outlined text-[18px]">
              {isDarkMode ? 'toggle_on' : 'toggle_off'}
            </span>
          </button>

          <button
            type="button"
            onClick={onToggleSound}
            className="p-3 rounded-xl bg-black/5 dark:bg-white/5 hover:bg-black/10 flex items-center justify-between text-xs font-bold text-[#191c1e] dark:text-white cursor-pointer"
          >
            <span>جلوه‌های صوتی</span>
            <span className="material-symbols-outlined text-[18px]">
              {soundEnabled ? 'volume_up' : 'volume_off'}
            </span>
          </button>
        </div>

        {/* Actions */}
        <div className="flex gap-2 justify-end pt-3 border-t border-black/10 dark:border-white/10">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs text-[#3c494e] dark:text-white hover:bg-black/5 cursor-pointer"
          >
            انصراف
          </button>
          <button
            onClick={handleSave}
            className="px-6 py-2 rounded-xl bg-gradient-to-r from-[#00677f] to-[#9500ca] text-white text-xs font-bold shadow-md cursor-pointer hover:opacity-90"
          >
            ذخیره تغییرات
          </button>
        </div>
      </div>
    </div>
  );
};
