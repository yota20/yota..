import React, { useState, useEffect } from 'react';
import { LiveStream, UserProfile } from '../types';
import { sounds } from '../utils/audio';

interface LiveStreamViewProps {
  streams: LiveStream[];
  selectedStream: LiveStream;
  onSelectStream: (stream: LiveStream) => void;
  user: UserProfile;
  onTipCoins: (amount: number) => void;
}

export const LiveStreamView: React.FC<LiveStreamViewProps> = ({
  streams,
  selectedStream,
  onSelectStream,
  user,
  onTipCoins,
}) => {
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isFollowing, setIsFollowing] = useState<boolean>(false);
  const [heartsCount, setHeartsCount] = useState<number>(142);
  const [floatingHearts, setFloatingHearts] = useState<{ id: number; x: number }[]>([]);
  const [showTipModal, setShowTipModal] = useState<boolean>(false);
  const [tipAmount, setTipAmount] = useState<number>(50);

  // Floating hearts animation trigger
  const handleSendHeart = () => {
    sounds.playCoin();
    setHeartsCount((prev) => prev + 1);
    const newHeart = {
      id: Date.now() + Math.random(),
      x: Math.random() * 60 + 20,
    };
    setFloatingHearts((prev) => [...prev, newHeart]);
    setTimeout(() => {
      setFloatingHearts((prev) => prev.filter((h) => h.id !== newHeart.id));
    }, 2000);
  };

  const handleTip = () => {
    if (user.dcCoins < tipAmount) return;
    sounds.playCoin();
    onTipCoins(tipAmount);
    setShowTipModal(false);
  };

  return (
    <div className="flex flex-col gap-6 pb-12 animate-slide-up">
      {/* Stream Theater Frame */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Main Video & Streamer Details (8 cols) */}
        <div className="xl:col-span-8 flex flex-col gap-4">
          <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-black border-2 border-white/20 shadow-2xl group">
            <img
              className="w-full h-full object-cover opacity-90"
              src={selectedStream.thumbnail}
              alt={selectedStream.title}
            />

            {/* Gradient Overlays */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40"></div>

            {/* Top Overlay Badges */}
            <div className="absolute top-4 left-4 right-4 flex justify-between items-center z-10">
              <div className="flex items-center gap-2">
                <span className="bg-red-600 text-white text-xs font-black px-2.5 py-1 rounded-lg flex items-center gap-1.5 shadow-lg animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-white"></span>
                  LIVE 1080P 60FPS
                </span>
                <span className="bg-black/60 backdrop-blur text-white text-xs font-bold px-2.5 py-1 rounded-lg border border-white/10 flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px]">visibility</span>
                  {selectedStream.viewers.toLocaleString('fa-IR')} بیننده
                </span>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="w-9 h-9 rounded-xl bg-black/60 backdrop-blur text-white flex items-center justify-center hover:bg-black/80 transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[20px]">
                    {isPlaying ? 'pause' : 'play_arrow'}
                  </span>
                </button>
              </div>
            </div>

            {/* Animated Floating Hearts */}
            {floatingHearts.map((heart) => (
              <div
                key={heart.id}
                className="absolute bottom-12 text-3xl pointer-events-none animate-float text-red-500 drop-shadow-[0_0_10px_red]"
                style={{ left: `${heart.x}%`, animationDuration: '1.8s' }}
              >
                ❤️
              </div>
            ))}

            {/* Stream Player Controls (Bottom) */}
            <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center z-10">
              <div className="flex items-center gap-3">
                <button
                  onClick={handleSendHeart}
                  className="px-3.5 py-1.5 rounded-xl bg-red-500/80 hover:bg-red-500 text-white text-xs font-bold backdrop-blur flex items-center gap-1.5 shadow-lg transition-transform active:scale-90 cursor-pointer"
                >
                  <span>❤️</span>
                  <span>{heartsCount} لایک</span>
                </button>

                <button
                  onClick={() => setShowTipModal(true)}
                  className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#bb00fc] to-[#9500ca] text-white text-xs font-bold backdrop-blur flex items-center gap-1.5 shadow-lg hover:scale-105 transition-all cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px]">diamond</span>
                  <span>ارسال دونیت DC</span>
                </button>
              </div>

              <span className="text-xs text-white/80 font-mono bg-black/50 px-2 py-1 rounded">
                سرور آسیا / پینگ: ۲۴ms
              </span>
            </div>
          </div>

          {/* Streamer Header Details */}
          <div className="glass-panel p-5 rounded-2xl border border-white/50 dark:border-white/10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex items-center gap-4">
              <img
                className="w-14 h-14 rounded-full object-cover border-2 border-[#00d2ff] shadow-md"
                src={selectedStream.streamerAvatar}
                alt={selectedStream.streamerName}
              />
              <div className="text-right">
                <h2 className="font-extrabold text-lg text-[#191c1e] dark:text-white flex items-center gap-1.5">
                  <span>{selectedStream.title}</span>
                  <span className="material-symbols-outlined text-[#00d2ff] text-[18px]">verified</span>
                </h2>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-sm font-bold text-[#00677f] dark:text-[#00d2ff]">
                    {selectedStream.streamerName}
                  </span>
                  <span className="text-xs text-[#3c494e]/70 dark:text-[#bfc8cc]/70">
                    • بازی: {selectedStream.category}
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                sounds.playCoin();
                setIsFollowing(!isFollowing);
              }}
              className={`px-6 py-2.5 rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer ${
                isFollowing
                  ? 'bg-black/10 dark:bg-white/10 text-[#191c1e] dark:text-white'
                  : 'bg-gradient-to-r from-[#00677f] to-[#9500ca] text-white hover:scale-105'
              }`}
            >
              {isFollowing ? '✓ دنبال می‌کنید' : '+ دنبال کردن استریمر'}
            </button>
          </div>

          {/* Stream Description */}
          {selectedStream.description && (
            <div className="glass-panel p-4 rounded-2xl border border-white/50 dark:border-white/10 text-xs text-[#3c494e] dark:text-[#bfc8cc] leading-relaxed">
              {selectedStream.description}
            </div>
          )}
        </div>

        {/* Other Active Channels (4 cols) */}
        <div className="xl:col-span-4 flex flex-col gap-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-sm text-[#191c1e] dark:text-white flex items-center gap-2">
              <span className="material-symbols-outlined text-[#bb00fc] text-[18px]">live_tv</span>
              <span>کانال‌های پخش زنده دیگر</span>
            </h3>
          </div>

          <div className="flex flex-col gap-3">
            {streams.map((stream) => (
              <div
                key={stream.id}
                onClick={() => {
                  sounds.playClick();
                  onSelectStream(stream);
                }}
                className={`glass-panel p-3 rounded-2xl border cursor-pointer transition-all flex gap-3 group ${
                  selectedStream.id === stream.id
                    ? 'border-[#00d2ff] ring-2 ring-[#00d2ff]/40 shadow-lg'
                    : 'border-white/50 dark:border-white/10 hover:border-[#00d2ff]/40'
                }`}
              >
                <div className="relative w-28 h-20 rounded-xl overflow-hidden shrink-0 border border-white/20">
                  <img
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    src={stream.thumbnail}
                    alt={stream.title}
                  />
                  <span className="absolute top-1 left-1 bg-red-600 text-white text-[9px] font-black px-1.5 py-0.5 rounded">
                    LIVE
                  </span>
                </div>
                <div className="flex-1 min-w-0 flex flex-col justify-between py-0.5">
                  <div>
                    <h4 className="font-bold text-xs text-[#191c1e] dark:text-white line-clamp-1 group-hover:text-[#00d2ff] transition-colors">
                      {stream.title}
                    </h4>
                    <p className="text-[11px] text-[#3c494e] dark:text-[#bfc8cc] mt-0.5">
                      {stream.streamerName}
                    </p>
                  </div>
                  <span className="text-[10px] text-[#23a559] font-semibold flex items-center gap-1">
                    <span className="material-symbols-outlined text-[12px]">person</span>
                    {stream.viewers.toLocaleString('fa-IR')} بیننده
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tip DC Modal */}
      {showTipModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#191c1e] p-6 rounded-2xl max-w-sm w-full border border-white/20 shadow-2xl animate-slide-up">
            <h3 className="font-bold text-lg text-[#191c1e] dark:text-white mb-2 flex items-center gap-2">
              <span className="material-symbols-outlined text-[#bb00fc]">diamond</span>
              حمایت از {selectedStream.streamerName}
            </h3>
            <p className="text-xs text-[#3c494e] dark:text-[#bfc8cc] mb-4">
              مقدار DicoCoins مورد نظر برای ارسال دونیت را انتخاب کنید:
            </p>

            <div className="grid grid-cols-3 gap-2 mb-4">
              {[25, 50, 100].map((amt) => (
                <button
                  key={amt}
                  onClick={() => setTipAmount(amt)}
                  className={`py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    tipAmount === amt
                      ? 'bg-[#bb00fc] text-white border-[#bb00fc] shadow'
                      : 'bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10 text-on-surface'
                  }`}
                >
                  {amt} DC
                </button>
              ))}
            </div>

            <div className="flex gap-2 justify-end">
              <button
                onClick={() => setShowTipModal(false)}
                className="px-4 py-2 rounded-xl text-xs text-[#3c494e] dark:text-white hover:bg-black/5 cursor-pointer"
              >
                انصراف
              </button>
              <button
                onClick={handleTip}
                disabled={user.dcCoins < tipAmount}
                className="px-6 py-2 rounded-xl bg-gradient-to-r from-[#bb00fc] to-[#9500ca] text-white text-xs font-bold shadow-md cursor-pointer hover:opacity-90 disabled:opacity-50"
              >
                ارسال دونیت ({tipAmount} DC)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
