import React, { useState } from 'react';
import { ActiveTab, Friend, UserProfile } from '../types';
import { sounds } from '../utils/audio';

interface NavigationSidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  user: UserProfile;
  friends: Friend[];
  onOpenSettings: () => void;
  onToggleMic: () => void;
  onFriendClick: (friend: Friend) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export const NavigationSidebar: React.FC<NavigationSidebarProps> = ({
  activeTab,
  setActiveTab,
  user,
  friends,
  onOpenSettings,
  onToggleMic,
  onFriendClick,
  searchQuery,
  setSearchQuery,
}) => {
  const [showAddFriendModal, setShowAddFriendModal] = useState(false);
  const [newFriendName, setNewFriendName] = useState('');

  const filteredFriends = friends.filter(
    (f) =>
      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.activity.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <aside
      id="main-nav-sidebar"
      className="fixed right-[72px] top-0 h-full z-40 hidden md:flex flex-col bg-[#f7f9fb]/60 dark:bg-[#111416]/80 backdrop-blur-2xl border-l border-white/20 dark:border-white/10 w-64 pt-5 select-none"
    >
      {/* Search Bar */}
      <div className="px-4 mb-4">
        <div className="relative">
          <input
            id="sidebar-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="جستجو..."
            className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-xl py-2 pl-4 pr-9 text-sm text-[#191c1e] dark:text-[#e0e3e5] focus:outline-none focus:border-[#00d2ff] focus:ring-1 focus:ring-[#00d2ff]/40 transition-all placeholder:text-[#3c494e]/60 dark:placeholder:text-[#bfc8cc]/60"
          />
          <span className="material-symbols-outlined absolute right-2.5 top-2.5 text-[#3c494e]/70 dark:text-[#bfc8cc]/70 text-[18px]">
            search
          </span>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute left-2.5 top-2.5 text-xs text-[#3c494e]/70 hover:text-black dark:text-white/70"
            >
              ×
            </button>
          )}
        </div>
      </div>

      {/* Main Nav Links */}
      <nav className="flex-1 flex flex-col gap-1 w-full px-3 overflow-y-auto hide-scrollbar">
        <div className="text-[11px] font-bold text-[#3c494e]/70 dark:text-[#bfc8cc]/70 uppercase tracking-wider mb-2 px-2">
          بخش اصلی
        </div>

        {/* 1. Discover */}
        <button
          id="nav-tab-discover"
          onClick={() => {
            sounds.playClick();
            setActiveTab('discover');
          }}
          className={`w-full rounded-xl flex items-center gap-3 px-3 py-2.5 transition-all text-sm font-semibold cursor-pointer ${
            activeTab === 'discover'
              ? 'bg-[#00677f]/15 dark:bg-[#00d2ff]/20 text-[#00677f] dark:text-[#00d2ff] font-bold shadow-sm'
              : 'text-[#3c494e] dark:text-[#bfc8cc] hover:bg-black/5 dark:hover:bg-white/5 hover:text-[#00677f] dark:hover:text-[#00d2ff]'
          }`}
        >
          <span
            className="material-symbols-outlined text-[20px]"
            style={{ fontVariationSettings: activeTab === 'discover' ? "'FILL' 1" : "'FILL' 0" }}
          >
            explore
          </span>
          <span>کشف کردن</span>
        </button>

        {/* 2. Live Streams */}
        <button
          id="nav-tab-live"
          onClick={() => {
            sounds.playClick();
            setActiveTab('live');
          }}
          className={`w-full rounded-xl flex items-center gap-3 px-3 py-2.5 transition-all text-sm font-semibold cursor-pointer ${
            activeTab === 'live'
              ? 'bg-[#00677f]/15 dark:bg-[#00d2ff]/20 text-[#00677f] dark:text-[#00d2ff] font-bold shadow-sm'
              : 'text-[#3c494e] dark:text-[#bfc8cc] hover:bg-black/5 dark:hover:bg-white/5 hover:text-[#00677f] dark:hover:text-[#00d2ff]'
          }`}
        >
          <span
            className="material-symbols-outlined text-[20px]"
            style={{ fontVariationSettings: activeTab === 'live' ? "'FILL' 1" : "'FILL' 0" }}
          >
            live_tv
          </span>
          <div className="flex-1 flex justify-between items-center">
            <span>پخش زنده</span>
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
          </div>
        </button>

        {/* 3. Tournaments */}
        <button
          id="nav-tab-tournaments"
          onClick={() => {
            sounds.playClick();
            setActiveTab('tournaments');
          }}
          className={`w-full rounded-xl flex items-center gap-3 px-3 py-2.5 transition-all text-sm font-semibold cursor-pointer ${
            activeTab === 'tournaments'
              ? 'bg-[#00677f]/15 dark:bg-[#00d2ff]/20 text-[#00677f] dark:text-[#00d2ff] font-bold shadow-sm'
              : 'text-[#3c494e] dark:text-[#bfc8cc] hover:bg-black/5 dark:hover:bg-white/5 hover:text-[#00677f] dark:hover:text-[#00d2ff]'
          }`}
        >
          <span
            className="material-symbols-outlined text-[20px]"
            style={{ fontVariationSettings: activeTab === 'tournaments' ? "'FILL' 1" : "'FILL' 0" }}
          >
            emoji_events
          </span>
          <div className="flex-1 flex justify-between items-center">
            <span>مسابقات</span>
            <span className="text-[10px] bg-[#bb00fc]/20 text-[#9500ca] dark:text-[#ecb2ff] px-1.5 py-0.5 rounded-full font-bold">
              جام ۵۰k
            </span>
          </div>
        </button>

        {/* 4. Games */}
        <button
          id="nav-tab-games"
          onClick={() => {
            sounds.playClick();
            setActiveTab('games');
          }}
          className={`w-full rounded-xl flex items-center gap-3 px-3 py-2.5 transition-all text-sm font-semibold cursor-pointer ${
            activeTab === 'games'
              ? 'bg-[#00677f]/15 dark:bg-[#00d2ff]/20 text-[#00677f] dark:text-[#00d2ff] font-bold shadow-sm'
              : 'text-[#3c494e] dark:text-[#bfc8cc] hover:bg-black/5 dark:hover:bg-white/5 hover:text-[#00677f] dark:hover:text-[#00d2ff]'
          }`}
        >
          <span
            className="material-symbols-outlined text-[20px]"
            style={{ fontVariationSettings: activeTab === 'games' ? "'FILL' 1" : "'FILL' 0" }}
          >
            sports_esports
          </span>
          <span>بازی‌های آنلاین</span>
        </button>

        {/* 5. Wallet */}
        <button
          id="nav-tab-wallet"
          onClick={() => {
            sounds.playClick();
            setActiveTab('wallet');
          }}
          className={`w-full rounded-xl flex items-center gap-3 px-3 py-2.5 transition-all text-sm font-semibold cursor-pointer ${
            activeTab === 'wallet'
              ? 'bg-[#00677f]/15 dark:bg-[#00d2ff]/20 text-[#00677f] dark:text-[#00d2ff] font-bold shadow-sm'
              : 'text-[#3c494e] dark:text-[#bfc8cc] hover:bg-black/5 dark:hover:bg-white/5 hover:text-[#00677f] dark:hover:text-[#00d2ff]'
          }`}
        >
          <span
            className="material-symbols-outlined text-[20px]"
            style={{ fontVariationSettings: activeTab === 'wallet' ? "'FILL' 1" : "'FILL' 0" }}
          >
            account_balance_wallet
          </span>
          <div className="flex-1 flex justify-between items-center">
            <span>کیف پول و پاداش</span>
            <span className="text-[11px] font-bold text-[#bb00fc] dark:text-[#ecb2ff]">
              {user.dcCoins.toLocaleString('fa-IR')} DC
            </span>
          </div>
        </button>

        {/* Online Friends Section */}
        <div className="flex justify-between items-center mt-5 mb-2 px-2">
          <span className="text-[11px] font-bold text-[#3c494e]/70 dark:text-[#bfc8cc]/70 uppercase tracking-wider">
            دوستان آنلاین ({filteredFriends.length})
          </span>
          <button
            id="btn-add-friend-trigger"
            onClick={() => setShowAddFriendModal(true)}
            className="p-1 rounded-md text-[#3c494e]/70 hover:text-[#00677f] dark:text-[#bfc8cc]/70 dark:hover:text-[#00d2ff] hover:bg-black/5 dark:hover:bg-white/5 transition-colors cursor-pointer"
            title="افزودن دوست جدید"
          >
            <span className="material-symbols-outlined text-[16px]">person_add</span>
          </button>
        </div>

        {/* Friends List */}
        <div className="flex flex-col gap-1">
          {filteredFriends.map((friend) => (
            <button
              key={friend.id}
              onClick={() => onFriendClick(friend)}
              className="w-full flex items-center gap-3 px-2 py-2 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition-all text-right group cursor-pointer"
            >
              <div className="relative w-8 h-8 rounded-full shrink-0">
                <img
                  className="w-full h-full rounded-full object-cover border border-white/40 shadow-sm"
                  src={friend.avatar}
                  alt={friend.name}
                />
                {friend.status === 'online' && (
                  <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-[#23a559] border-2 border-[#f7f9fb] dark:border-[#111416] rounded-full"></div>
                )}
                {friend.status === 'idle' && (
                  <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-[#f0b232] border-2 border-[#f7f9fb] dark:border-[#111416] rounded-full flex items-center justify-center">
                    <span
                      className="material-symbols-outlined text-[8px] text-black"
                      style={{ fontVariationSettings: "'FILL' 1" }}
                    >
                      nightlight
                    </span>
                  </div>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <p className="text-sm font-semibold text-[#191c1e] dark:text-[#e0e3e5] truncate group-hover:text-[#00677f] dark:group-hover:text-[#00d2ff] transition-colors">
                    {friend.name}
                  </p>
                  {friend.isVip && (
                    <span className="material-symbols-outlined text-[13px] text-[#bb00fc]" title="VIP Diamond">
                      diamond
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-[#3c494e]/80 dark:text-[#bfc8cc]/80 truncate">
                  {friend.activity}
                </p>
              </div>

              <span className="material-symbols-outlined text-[14px] text-transparent group-hover:text-[#3c494e]/50 dark:group-hover:text-white/40 transition-colors">
                chat
              </span>
            </button>
          ))}
        </div>
      </nav>

      {/* User Profile Bar at bottom (Discord style) */}
      <div className="p-3 bg-black/5 dark:bg-black/40 border-t border-black/10 dark:border-white/10 flex items-center gap-2">
        <div
          onClick={onOpenSettings}
          className="relative w-10 h-10 rounded-full cursor-pointer hover:ring-2 hover:ring-[#00d2ff] transition-all overflow-hidden shrink-0"
          title="تنظیمات پروفایل"
        >
          <img className="w-full h-full object-cover" src={user.avatar} alt={user.name} />
          <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-[#23a559] border-2 border-white rounded-full"></div>
        </div>

        <div className="flex-1 min-w-0 cursor-pointer" onClick={onOpenSettings}>
          <div className="flex items-center gap-1">
            <h3 className="font-bold text-sm text-[#191c1e] dark:text-[#e0e3e5] truncate hover:text-[#00677f] dark:hover:text-[#00d2ff]">
              {user.name}
            </h3>
            {user.vipTier === 'diamond' && (
              <span className="material-symbols-outlined text-[13px] text-[#bb00fc]">diamond</span>
            )}
          </div>
          <p className="text-xs text-[#9500ca] dark:text-[#ecb2ff] font-medium truncate">{user.statusText}</p>
        </div>

        <div className="flex gap-1 items-center">
          {/* Mic Mute/Unmute */}
          <button
            id="btn-toggle-mic"
            onClick={() => {
              sounds.playClick();
              onToggleMic();
            }}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              user.isMuted
                ? 'bg-red-500/10 text-red-500 hover:bg-red-500/20'
                : 'text-[#3c494e] dark:text-[#bfc8cc] hover:bg-black/10 dark:hover:bg-white/10 hover:text-black dark:hover:text-white'
            }`}
            title={user.isMuted ? 'میکروفون قطع است (کلیک برای وصل)' : 'میکروفون فعال است (کلیک برای قطع)'}
          >
            <span className="material-symbols-outlined text-[18px]">
              {user.isMuted ? 'mic_off' : 'mic'}
            </span>
          </button>

          {/* Settings */}
          <button
            id="btn-open-settings"
            onClick={() => {
              sounds.playClick();
              onOpenSettings();
            }}
            className="p-1.5 rounded-lg text-[#3c494e] dark:text-[#bfc8cc] hover:bg-black/10 dark:hover:bg-white/10 hover:text-black dark:hover:text-white transition-colors cursor-pointer"
            title="تنظیمات"
          >
            <span className="material-symbols-outlined text-[18px]">settings</span>
          </button>
        </div>
      </div>

      {/* Quick Add Friend Modal */}
      {showAddFriendModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#191c1e] p-6 rounded-2xl max-w-sm w-full border border-white/20 shadow-2xl animate-slide-up">
            <h3 className="font-bold text-lg text-[#191c1e] dark:text-white mb-2 flex items-center gap-2">
              <span className="material-symbols-outlined text-[#00d2ff]">person_add</span>
              افزودن دوست جدید
            </h3>
            <p className="text-xs text-[#3c494e] dark:text-[#bfc8cc] mb-4">
              شناسه یا نام کاربری دوست خود را وارد کنید تا درخواست دوستی ارسال شود:
            </p>
            <input
              type="text"
              value={newFriendName}
              onChange={(e) => setNewFriendName(e.target.value)}
              placeholder="مثلاً: CyberKid#1234"
              className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-xl p-3 text-sm text-on-surface mb-4 focus:outline-none focus:border-[#00d2ff]"
              autoFocus
            />
            <div className="flex gap-2 justify-end">
              <button
                onClick={() => setShowAddFriendModal(false)}
                className="px-4 py-2 rounded-xl text-sm text-[#3c494e] dark:text-white hover:bg-black/5 cursor-pointer"
              >
                انصراف
              </button>
              <button
                onClick={() => {
                  if (newFriendName.trim()) {
                    sounds.playCoin();
                    setShowAddFriendModal(false);
                    setNewFriendName('');
                  }
                }}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#00677f] to-[#9500ca] text-white text-sm font-bold shadow-md cursor-pointer hover:opacity-90"
              >
                ارسال درخواست
              </button>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
};
