import React from 'react';
import { GameItem, LiveStream, Tournament } from '../types';
import { sounds } from '../utils/audio';

interface DiscoverViewProps {
  streams: LiveStream[];
  games: GameItem[];
  tournaments: Tournament[];
  onSelectStream: (stream: LiveStream) => void;
  onSelectGame: (gameId: string) => void;
  onOpenTournaments: () => void;
  onQuickPlay: () => void;
}

export const DiscoverView: React.FC<DiscoverViewProps> = ({
  streams,
  games,
  tournaments,
  onSelectStream,
  onSelectGame,
  onOpenTournaments,
  onQuickPlay,
}) => {
  return (
    <div className="flex flex-col gap-6 pb-12 animate-slide-up">
      {/* 1. Hero Section (Matching exact mockup structure and design) */}
      <section
        id="hero-section"
        className="relative glass-panel rounded-2xl p-6 md:p-10 flex flex-col md:flex-row items-center justify-between overflow-hidden shadow-[0_10px_40px_rgba(0,103,127,0.08)] dark:shadow-[0_10px_40px_rgba(0,0,0,0.4)] border border-white/40 dark:border-white/10"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-[#00d2ff]/10 via-[#bb00fc]/5 to-transparent z-0 pointer-events-none"></div>

        <div className="relative z-10 md:w-7/12 flex flex-col gap-5 text-right">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#00d2ff]/10 dark:bg-[#00d2ff]/20 border border-[#00d2ff]/30 text-[#00677f] dark:text-[#00d2ff] w-fit text-xs md:text-sm font-bold shadow-sm">
            <span className="material-symbols-outlined text-[18px]">verified</span>
            <span>به متاورس خوش آمدید</span>
          </div>

          <h1 className="text-3xl md:text-5xl font-extrabold text-[#191c1e] dark:text-white leading-[1.2] tracking-tight">
            <span className="block font-black">DicoPick :</span>
            <span className="text-gradient block font-black mt-1">بازی کن، چت کن،</span>
            <span className="text-gradient block font-black mt-1">دوست پیدا کن</span>
          </h1>

          <p className="text-sm md:text-base text-[#3c494e] dark:text-[#bfc8cc] max-w-lg leading-relaxed font-normal">
            به دنیایی از بازی‌های اجتماعی پرانرژی شیرجه بزنید. ارتباط برقرار کنید، رقابت کنید و
            جوایز را در یک اکوسیستم دیجیتال پر جنب و جوش جمع‌آوری کنید.
          </p>

          <div className="flex flex-wrap gap-3 mt-2">
            <button
              id="btn-hero-play"
              onClick={() => {
                sounds.playCoin();
                onQuickPlay();
              }}
              className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-[#00677f] to-[#9500ca] hover:from-[#00566a] hover:to-[#74009f] text-white font-bold text-sm md:text-base hover:scale-105 hover:shadow-[0_0_25px_rgba(187,0,252,0.5)] transition-all duration-300 flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <span className="material-symbols-outlined text-[20px]">sports_esports</span>
              <span>شروع بازی</span>
            </button>

            <button
              onClick={() => {
                sounds.playClick();
                onSelectStream(streams[0]);
              }}
              className="px-6 py-3.5 rounded-xl bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 text-[#191c1e] dark:text-white font-bold text-sm md:text-base transition-all duration-200 border border-black/10 dark:border-white/10 flex items-center gap-2 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[20px] text-red-500 animate-pulse">
                live_tv
              </span>
              <span>تماشای زنده فینال</span>
            </button>
          </div>
        </div>

        {/* Hero Decorative Interactive Element */}
        <div className="relative z-10 md:w-5/12 mt-6 md:mt-0 flex justify-center items-center">
          <div className="relative w-full max-w-xs aspect-square flex items-center justify-center">
            {/* Ambient Background Glow */}
            <div className="absolute inset-0 bg-gradient-to-tr from-[#00d2ff]/30 to-[#bb00fc]/30 rounded-full blur-3xl animate-pulse-glow"></div>

            {/* Glass Interactive Floating Card Preview */}
            <div className="relative bg-white/70 dark:bg-[#191c1e]/80 backdrop-blur-xl p-4 rounded-2xl border border-white/60 dark:border-white/10 shadow-2xl w-full flex flex-col gap-3 animate-float">
              <div className="flex justify-between items-center pb-2 border-b border-black/5 dark:border-white/10">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#23a559] animate-ping"></span>
                  <span className="text-xs font-bold text-[#191c1e] dark:text-white">
                    اتاق فعال #804
                  </span>
                </div>
                <span className="text-[10px] bg-[#bb00fc]/15 text-[#bb00fc] dark:text-[#ecb2ff] px-2 py-0.5 rounded-full font-bold">
                  Neon Ludo
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="bg-black/5 dark:bg-white/5 p-2 rounded-xl flex items-center gap-2">
                  <img
                    className="w-7 h-7 rounded-full object-cover"
                    src={streams[0].streamerAvatar}
                    alt="Alex"
                  />
                  <div className="min-w-0">
                    <p className="text-[11px] font-bold truncate text-[#191c1e] dark:text-white">
                      Alex Nova
                    </p>
                    <p className="text-[9px] text-[#23a559]">آماده (۱,۲۵۰ DC)</p>
                  </div>
                </div>
                <div className="bg-black/5 dark:bg-white/5 p-2 rounded-xl flex items-center gap-2">
                  <img
                    className="w-7 h-7 rounded-full object-cover"
                    src={streams[1].streamerAvatar}
                    alt="CyberKid"
                  />
                  <div className="min-w-0">
                    <p className="text-[11px] font-bold truncate text-[#191c1e] dark:text-white">
                      CyberKid
                    </p>
                    <p className="text-[9px] text-[#23a559]">آماده (۸۹۰ DC)</p>
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  sounds.playCoin();
                  onSelectGame('game-ludo');
                }}
                className="w-full py-2 bg-gradient-to-r from-[#00d2ff] to-[#00677f] text-white text-xs font-bold rounded-xl shadow hover:opacity-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[16px]">play_arrow</span>
                <span>ورود به بازی نئون لودو</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Top Live Streams Section (Matching exact screenshot cards) */}
      <section id="live-streams-section" className="flex flex-col gap-4">
        <div className="flex justify-between items-center">
          <h2 className="text-lg md:text-xl font-bold text-[#191c1e] dark:text-white flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse"></span>
            <span>برترین‌های در حال پخش</span>
          </h2>
          <button
            onClick={() => {
              sounds.playClick();
              onSelectStream(streams[0]);
            }}
            className="text-[#00677f] dark:text-[#00d2ff] text-xs md:text-sm font-bold hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>مشاهده همه</span>
            <span className="material-symbols-outlined text-[16px]">arrow_back</span>
          </button>
        </div>

        {/* Live Grid Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {streams.map((stream) => (
            <div
              key={stream.id}
              onClick={() => {
                sounds.playClick();
                onSelectStream(stream);
              }}
              className="group cursor-pointer bg-white/40 dark:bg-white/5 rounded-2xl p-2.5 border border-black/10 dark:border-white/10 hover:border-[#00d2ff]/60 dark:hover:border-[#00d2ff]/60 transition-all duration-300 hover:shadow-xl hover:-translate-y-1"
            >
              <div className="relative aspect-video rounded-xl overflow-hidden mb-3 border border-black/5 dark:border-white/10">
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent z-10"></div>
                <img
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  src={stream.thumbnail}
                  alt={stream.title}
                />
                <div className="absolute top-2.5 left-2.5 z-20 bg-red-600 text-white text-[11px] font-extrabold px-2 py-0.5 rounded-md shadow flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping"></span>
                  LIVE
                </div>
                <div className="absolute bottom-2.5 left-2.5 z-20 bg-black/70 backdrop-blur text-white text-xs font-bold px-2.5 py-1 rounded-lg flex items-center gap-1.5 border border-white/10">
                  <span className="material-symbols-outlined text-[14px]">person</span>
                  <span>{stream.viewers.toLocaleString('fa-IR')}</span>
                </div>
              </div>

              <div className="flex gap-3 px-1">
                <img
                  className={`w-10 h-10 rounded-full object-cover border-2 shrink-0 ${
                    stream.category === 'Neon Ludo' ? 'border-[#00d2ff]' : 'border-[#bb00fc]'
                  }`}
                  src={stream.streamerAvatar}
                  alt={stream.streamerName}
                />
                <div className="min-w-0 flex-1">
                  <h3 className="text-sm font-bold text-[#191c1e] dark:text-white line-clamp-1 group-hover:text-[#00677f] dark:group-hover:text-[#00d2ff] transition-colors">
                    {stream.title}
                  </h3>
                  <p className="text-xs text-[#3c494e] dark:text-[#bfc8cc] font-medium mt-0.5">
                    {stream.streamerName}
                  </p>
                  <div className="flex gap-1.5 mt-1.5">
                    <span className="text-[10px] bg-black/5 dark:bg-white/10 px-2 py-0.5 rounded-md text-[#3c494e] dark:text-[#bfc8cc] font-medium">
                      {stream.category}
                    </span>
                    <span className="text-[10px] bg-black/5 dark:bg-white/10 px-2 py-0.5 rounded-md text-[#3c494e] dark:text-[#bfc8cc] font-medium">
                      {stream.language}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Featured Playable Metaverse Games Grid */}
      <section id="featured-games-section" className="flex flex-col gap-4 mt-2">
        <div className="flex justify-between items-center">
          <h2 className="text-lg md:text-xl font-bold text-[#191c1e] dark:text-white flex items-center gap-2">
            <span className="material-symbols-outlined text-[#bb00fc] text-2xl">sports_esports</span>
            <span>بازی‌های محبوب برای شروع سریع</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {games.map((game) => (
            <div
              key={game.id}
              className="glass-panel p-4 rounded-2xl border border-white/50 dark:border-white/10 flex flex-col md:flex-row gap-4 items-center group hover:shadow-xl transition-all"
            >
              <div className="relative w-full md:w-36 h-28 rounded-xl overflow-hidden shrink-0 border border-white/30">
                <img
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  src={game.thumbnail}
                  alt={game.title}
                />
                <span className="absolute top-2 right-2 text-[10px] bg-black/70 text-white px-1.5 py-0.5 rounded font-bold">
                  ⭐ {game.rating}
                </span>
              </div>

              <div className="flex-1 min-w-0 flex flex-col justify-between h-full">
                <div>
                  <h3 className="font-bold text-base text-[#191c1e] dark:text-white">
                    {game.title}
                  </h3>
                  <p className="text-xs text-[#3c494e] dark:text-[#bfc8cc] line-clamp-2 mt-1 leading-relaxed">
                    {game.description}
                  </p>
                </div>

                <div className="flex justify-between items-center mt-3">
                  <span className="text-xs text-[#23a559] font-semibold flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-[#23a559]"></span>
                    {game.playersOnline.toLocaleString('fa-IR')} بازیکن آنلاین
                  </span>

                  <button
                    onClick={() => {
                      sounds.playCoin();
                      onSelectGame(game.id);
                    }}
                    className={`px-4 py-1.5 rounded-xl text-white text-xs font-bold bg-gradient-to-r ${game.colorGradient} hover:shadow-lg transition-all cursor-pointer hover:scale-105`}
                  >
                    اجرا و بازی
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Tournaments Teaser Card */}
      <section className="bg-gradient-to-r from-[#00677f]/10 via-[#9500ca]/15 to-[#00d2ff]/10 p-5 rounded-2xl border border-[#00d2ff]/30 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#f59e0b] to-[#ec4899] text-white flex items-center justify-center shadow-lg shrink-0">
            <span className="material-symbols-outlined text-2xl">emoji_events</span>
          </div>
          <div>
            <h3 className="font-bold text-base text-[#191c1e] dark:text-white">
              جام مسابقات هفتگی DicoPick با جایزه ۵۰,۰۰۰ DC
            </h3>
            <p className="text-xs text-[#3c494e] dark:text-[#bfc8cc] mt-0.5">
              مهلت ثبت‌نام تا ۳ ساعت دیگر. رقابت آنلاین بین ۶۴ بازیکن برتر سرور!
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            sounds.playClick();
            onOpenTournaments();
          }}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#9500ca] to-[#bb00fc] text-white text-xs font-bold hover:shadow-lg transition-all whitespace-nowrap cursor-pointer hover:scale-105"
        >
          مشاهده جدول و ثبت‌نام
        </button>
      </section>
    </div>
  );
};
