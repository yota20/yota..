import React, { useState, useEffect, useRef } from 'react';
import { sounds } from '../../utils/audio';

interface AeroSprintGameProps {
  onEarnCoins: (amount: number) => void;
  onClose?: () => void;
}

interface Obstacle {
  x: number; // 0, 1, 2 (lanes)
  y: number; // 0 to 100%
  type: 'barrier' | 'energy' | 'nitro';
  id: number;
}

export const AeroSprintGame: React.FC<AeroSprintGameProps> = ({ onEarnCoins, onClose }) => {
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [lane, setLane] = useState<number>(1); // 0 = Left, 1 = Center, 2 = Right
  const [score, setScore] = useState<number>(0);
  const [speed, setSpeed] = useState<number>(180);
  const [nitro, setNitro] = useState<number>(75);
  const [isBoosting, setIsBoosting] = useState<boolean>(false);
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [obstacles, setObstacles] = useState<Obstacle[]>([]);
  const gameLoopRef = useRef<number | null>(null);
  const nextId = useRef<number>(1);

  // Start game
  const startGame = () => {
    sounds.playBoost();
    setIsPlaying(true);
    setGameOver(false);
    setScore(0);
    setSpeed(180);
    setNitro(80);
    setLane(1);
    setObstacles([
      { id: nextId.current++, x: 0, y: 15, type: 'energy' },
      { id: nextId.current++, x: 2, y: 35, type: 'barrier' },
      { id: nextId.current++, x: 1, y: 65, type: 'energy' },
      { id: nextId.current++, x: 0, y: 85, type: 'nitro' },
    ]);
  };

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isPlaying || gameOver) return;
      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        // RTL Right is lane 0
        setLane((prev) => Math.max(0, prev - 1));
        sounds.playClick();
      } else if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        // RTL Left is lane 2
        setLane((prev) => Math.min(2, prev + 1));
        sounds.playClick();
      } else if (e.key === ' ' || e.key === 'ArrowUp' || e.key === 'w') {
        triggerBoost();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, gameOver, nitro]);

  const triggerBoost = () => {
    if (nitro >= 20 && !isBoosting) {
      sounds.playBoost();
      setIsBoosting(true);
      setNitro((prev) => Math.max(0, prev - 25));
      setTimeout(() => setIsBoosting(false), 1500);
    }
  };

  // Game Loop
  useEffect(() => {
    if (!isPlaying || gameOver) return;

    const interval = setInterval(() => {
      const step = isBoosting ? 2.5 : 1.2;
      setScore((prev) => prev + (isBoosting ? 15 : 5));
      setSpeed(isBoosting ? 320 : 180 + Math.min(100, Math.floor(score / 50)));

      // Regenerate nitro slowly
      setNitro((prev) => Math.min(100, prev + 0.1));

      // Move obstacles down
      setObstacles((prev) => {
        const updated: Obstacle[] = [];
        let hitBarrier = false;

        for (const ob of prev) {
          const newY = ob.y + step;

          // Collision check near player (y ~ 82..92)
          if (newY >= 80 && newY <= 92 && ob.x === lane) {
            if (ob.type === 'barrier') {
              hitBarrier = true;
            } else if (ob.type === 'energy') {
              sounds.playCoin();
              setScore((s) => s + 50);
              continue; // collected
            } else if (ob.type === 'nitro') {
              sounds.playBoost();
              setNitro((n) => Math.min(100, n + 35));
              continue; // collected
            }
          }

          if (newY < 105) {
            updated.push({ ...ob, y: newY });
          }
        }

        if (hitBarrier) {
          setGameOver(true);
          setIsPlaying(false);
          const earned = Math.max(10, Math.floor(score / 15));
          onEarnCoins(earned);
          return [];
        }

        // Spawn new obstacle occasionally
        if (Math.random() < 0.25 && updated.length < 5) {
          const spawnX = Math.floor(Math.random() * 3);
          const randType = Math.random();
          const type: 'barrier' | 'energy' | 'nitro' =
            randType < 0.5 ? 'barrier' : randType < 0.85 ? 'energy' : 'nitro';
          updated.push({
            id: nextId.current++,
            x: spawnX,
            y: 0,
            type,
          });
        }

        return updated;
      });
    }, 30);

    return () => clearInterval(interval);
  }, [isPlaying, gameOver, lane, isBoosting, score]);

  return (
    <div className="glass-panel p-4 md:p-6 rounded-2xl border border-white/60 dark:border-white/10 shadow-2xl flex flex-col gap-4 select-none animate-slide-up">
      {/* Header */}
      <div className="flex justify-between items-center pb-3 border-b border-black/10 dark:border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#bb00fc] to-[#9500ca] flex items-center justify-center text-white shadow-lg">
            <span className="material-symbols-outlined text-2xl">electric_bolt</span>
          </div>
          <div>
            <h2 className="font-extrabold text-lg md:text-xl text-[#191c1e] dark:text-white">
              Aero Sprint: Cyber Skyway
            </h2>
            <p className="text-xs text-[#3c494e] dark:text-[#bfc8cc]">
              سرعت در اتوبان هوایی نئونی - کنترل با کلیدهای جهت‌نما یا دکمه‌های صفحه
            </p>
          </div>
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-black/5 dark:bg-white/10 text-xs font-bold hover:bg-black/10 cursor-pointer"
          >
            خروج از بازی
          </button>
        )}
      </div>

      {/* Main Track Screen */}
      <div className="relative w-full h-80 md:h-96 rounded-2xl bg-[#0a0d10] overflow-hidden border-2 border-[#bb00fc]/40 shadow-[0_0_30px_rgba(187,0,252,0.2)] flex flex-col justify-between">
        {/* Skyway Perspective Grid Lines */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#bb00fc]/10 to-[#00d2ff]/10"></div>
        <div className="absolute inset-x-0 top-0 h-1/3 bg-gradient-to-b from-[#18002e] to-transparent flex items-center justify-center">
          <div className="text-xs text-[#bb00fc] tracking-widest uppercase font-mono opacity-60">
            METROPOLIS SKYWAY SECTOR-7
          </div>
        </div>

        {/* 3 Lanes Dividers */}
        <div className="absolute inset-0 flex justify-evenly pointer-events-none">
          <div className="w-[1px] h-full bg-dashed border-r border-[#00d2ff]/20"></div>
          <div className="w-[1px] h-full bg-dashed border-r border-[#00d2ff]/20"></div>
        </div>

        {/* Dynamic Obstacles / Orbs */}
        {obstacles.map((ob) => (
          <div
            key={ob.id}
            className="absolute transition-all duration-75 -translate-x-1/2 flex items-center justify-center"
            style={{
              top: `${ob.y}%`,
              left: `${ob.x === 0 ? 16 : ob.x === 1 ? 50 : 84}%`,
            }}
          >
            {ob.type === 'barrier' && (
              <div className="w-12 h-6 bg-red-600 rounded-lg border border-red-300 shadow-[0_0_15px_red] flex items-center justify-center text-[10px] font-black text-white">
                ⚠️ BARRIER
              </div>
            )}
            {ob.type === 'energy' && (
              <div className="w-8 h-8 rounded-full bg-[#00d2ff] border-2 border-white shadow-[0_0_18px_#00d2ff] flex items-center justify-center text-xs font-bold text-black animate-pulse">
                ⚡
              </div>
            )}
            {ob.type === 'nitro' && (
              <div className="w-9 h-9 rounded-full bg-[#bb00fc] border-2 border-white shadow-[0_0_20px_#bb00fc] flex items-center justify-center text-xs font-bold text-white animate-bounce">
                🚀
              </div>
            )}
          </div>
        ))}

        {/* Player Jet/Bike */}
        {isPlaying && (
          <div
            className="absolute bottom-6 -translate-x-1/2 transition-all duration-150 flex flex-col items-center"
            style={{
              left: `${lane === 0 ? 16 : lane === 1 ? 50 : 84}%`,
            }}
          >
            {/* Boost Trail Flame */}
            {isBoosting && (
              <div className="w-4 h-12 bg-gradient-to-t from-transparent via-[#00d2ff] to-[#bb00fc] rounded-full blur-xs animate-ping mb-1"></div>
            )}
            <div
              className={`w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#00d2ff] via-[#bb00fc] to-[#9500ca] p-0.5 border-2 border-white shadow-[0_0_25px_rgba(0,210,255,0.8)] flex items-center justify-center ${
                isBoosting ? 'scale-110' : ''
              }`}
            >
              <span className="material-symbols-outlined text-white text-3xl">sports_motorsports</span>
            </div>
          </div>
        )}

        {/* HUD Overlay Stats (Top) */}
        <div className="relative z-10 p-4 flex justify-between items-center">
          <div className="flex gap-4">
            <div className="bg-black/60 backdrop-blur px-3 py-1.5 rounded-xl border border-white/10 text-right">
              <span className="text-[10px] text-[#bfc8cc] block">امتیاز:</span>
              <span className="font-extrabold text-sm text-[#00d2ff]">
                {score.toLocaleString('fa-IR')}
              </span>
            </div>
            <div className="bg-black/60 backdrop-blur px-3 py-1.5 rounded-xl border border-white/10 text-right">
              <span className="text-[10px] text-[#bfc8cc] block">سرعت:</span>
              <span className="font-extrabold text-sm text-white">{speed} KM/H</span>
            </div>
          </div>

          {/* Nitro Gauge */}
          <div className="w-36 bg-black/60 backdrop-blur p-2 rounded-xl border border-white/10 flex flex-col gap-1">
            <div className="flex justify-between text-[10px] text-[#bfc8cc]">
              <span>نیترو بوست</span>
              <span className="font-bold text-[#bb00fc]">{Math.floor(nitro)}%</span>
            </div>
            <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#00d2ff] to-[#bb00fc] transition-all"
                style={{ width: `${nitro}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Game Start / Over Modal Overlay */}
        {!isPlaying && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-20">
            {gameOver ? (
              <div className="flex flex-col items-center gap-2 animate-slide-up">
                <span className="material-symbols-outlined text-4xl text-red-500">dangerous</span>
                <h3 className="font-black text-2xl text-white">تصادف در اتوبان!</h3>
                <p className="text-sm text-[#bfc8cc]">
                  امتیاز نهایی: <span className="text-[#00d2ff] font-bold">{score}</span>
                </p>
                <p className="text-xs text-[#23a559] font-semibold">
                  +{(Math.max(10, Math.floor(score / 15))).toLocaleString('fa-IR')} DC به کیف پول شما واریز شد!
                </p>
                <button
                  onClick={startGame}
                  className="mt-3 px-8 py-3 rounded-xl bg-gradient-to-r from-[#bb00fc] to-[#9500ca] text-white font-extrabold text-sm shadow-xl hover:scale-105 transition-all cursor-pointer"
                >
                  شروع دوباره مسابقه
                </button>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-3 animate-slide-up">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#bb00fc] to-[#00d2ff] flex items-center justify-center text-white shadow-[0_0_30px_rgba(187,0,252,0.6)]">
                  <span className="material-symbols-outlined text-4xl">rocket_launch</span>
                </div>
                <h3 className="font-black text-2xl text-white">Aero Sprint Racing</h3>
                <p className="text-xs text-[#bfc8cc] max-w-xs leading-relaxed">
                  با کلیدهای جهت‌نما یا دکمه‌های لمسی حرکت کنید، موانع را رد کنید و انرژی نئونی جمع کنید!
                </p>
                <button
                  id="btn-start-aero-race"
                  onClick={startGame}
                  className="px-8 py-3 rounded-xl bg-gradient-to-r from-[#00d2ff] to-[#bb00fc] text-white font-extrabold text-sm shadow-xl hover:scale-105 transition-all cursor-pointer"
                >
                  استارت موتور و پرواز
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* On-Screen Touch Controls (Great for Touch / Mobile or Mouse) */}
      <div className="flex justify-between items-center pt-2">
        <div className="flex gap-2">
          <button
            onClick={() => {
              if (isPlaying && !gameOver) {
                sounds.playClick();
                setLane((prev) => Math.min(2, prev + 1));
              }
            }}
            className="w-14 h-12 rounded-xl bg-black/10 dark:bg-white/10 hover:bg-black/20 flex items-center justify-center font-bold text-lg text-[#191c1e] dark:text-white cursor-pointer active:scale-90"
            title="حرکت به چپ"
          >
            <span className="material-symbols-outlined">arrow_forward</span>
          </button>
          <button
            onClick={() => {
              if (isPlaying && !gameOver) {
                sounds.playClick();
                setLane((prev) => Math.max(0, prev - 1));
              }
            }}
            className="w-14 h-12 rounded-xl bg-black/10 dark:bg-white/10 hover:bg-black/20 flex items-center justify-center font-bold text-lg text-[#191c1e] dark:text-white cursor-pointer active:scale-90"
            title="حرکت به راست"
          >
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
        </div>

        <button
          onClick={triggerBoost}
          disabled={!isPlaying || nitro < 20}
          className="px-6 h-12 rounded-xl bg-gradient-to-r from-[#00d2ff] to-[#bb00fc] text-white font-bold text-xs flex items-center gap-1.5 shadow-md hover:scale-105 active:scale-95 disabled:opacity-50 cursor-pointer"
        >
          <span className="material-symbols-outlined text-[18px]">bolt</span>
          <span>شتاب نیترو (Space)</span>
        </button>
      </div>
    </div>
  );
};
