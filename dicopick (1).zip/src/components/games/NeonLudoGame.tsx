import React, { useState, useEffect } from 'react';
import { sounds } from '../../utils/audio';

interface NeonLudoGameProps {
  onEarnCoins: (amount: number) => void;
  onClose?: () => void;
}

interface Player {
  id: string;
  name: string;
  color: string;
  avatar: string;
  tokens: number[]; // positions 0 = home, 1..56 = on track, 57 = finished
  isAi: boolean;
}

export const NeonLudoGame: React.FC<NeonLudoGameProps> = ({ onEarnCoins, onClose }) => {
  const [diceValue, setDiceValue] = useState<number>(6);
  const [isRolling, setIsRolling] = useState<boolean>(false);
  const [currentTurn, setCurrentTurn] = useState<number>(0); // 0 = Player (Cyan), 1 = Alex Nova (Magenta), 2 = CyberKid (Green), 3 = TigerClaw (Yellow)
  const [gameLog, setGameLog] = useState<string[]>([
    'به بازی Neon Ludo Strike خوش آمدید! نوبت شماست (تیم آبی نئون). تاس بیندازید!',
  ]);
  const [winner, setWinner] = useState<string | null>(null);

  const [players, setPlayers] = useState<Player[]>([
    {
      id: 'p1',
      name: 'شما (Cyan)',
      color: '#00d2ff',
      avatar:
        'https://lh3.googleusercontent.com/aida-public/AB6AXuC55ToRYeQqupVjkDGr3KFmy40GVV91EtoRfBg6fmPgLueVifmz3z7yEFiBEg9l3_JsXhHACaBjbql5_Vjvj9-TZ3pnCZ4Bm5Niu4alLLDQIFWgBotpzkjkGjyUWhqu92qt3fgo9ZL6Tu87Gq0UkBLFRWlKAq1kfM0_LhUHEhV7ruxzV1TDEHOvft-bo30cYqfN0H6TOdbR0hY2peGvEzaOkUWltTHOgCVukGovb2rb1ISzNCUzb3db',
      tokens: [1, 0, 0, 0],
      isAi: false,
    },
    {
      id: 'p2',
      name: 'Alex Nova',
      color: '#bb00fc',
      avatar:
        'https://lh3.googleusercontent.com/aida-public/AB6AXuDXFdfwzDl_nYbIDUrjoucCHg6iu0BA59WXeS7AvAnyGuJBN13rmrHJvnr_t0QF6rXORW8DO2yJrSp00H82tT8wGqfw-nBq4izuJUqUproaDEdAzzr3UYsOcvwXP2PHCS1_l1zdS2p8edgLSeaz18QFRvs8t1076syvg96wBCQ7of8_escATNPrVSCSTXpBmvgOB1qAkrZ7ED5hL4KotljwdLtJTp2tA5hnCjvwQbAFQHhLE0NFsDp2',
      tokens: [1, 0, 0, 0],
      isAi: true,
    },
    {
      id: 'p3',
      name: 'CyberKid',
      color: '#23a559',
      avatar:
        'https://lh3.googleusercontent.com/aida-public/AB6AXuDUnjPJ4yuoYE7Pr6UTZccTf2tCMz1aPODGAhVb2wVe_u1Z1LU4hdIIlV03a7piXI2YWAtH3KGfsYdeOXf5GIbnxnEdP_idq2C1PHyJLc0uUwShzw8zwIWUsx8BPiNZjhvtkFnZnUdtXvIZ_K-pRaBlnfD19NLcivS1l8QfP9dHcXDLlRr7c69cLedvQTH0X8mSoXRDrSjVUNeFx2z7Jb1SqkCIR8LpG-JVx_vXxeNtC7TljP3IVvzp',
      tokens: [1, 0, 0, 0],
      isAi: true,
    },
    {
      id: 'p4',
      name: 'TigerClaw',
      color: '#f0b232',
      avatar:
        'https://lh3.googleusercontent.com/aida-public/AB6AXuCIIHn6jp5CtBRFYA_avyKo-2sW_Hpet0x8G_33_CihDGXvfTXigmzYVO6a_fv4enOkwSAdsk1ZQPnLvxktnMEylC3WBJk2kjUPEx9plh96milQ07PF_XBEHfoMRg465cFdSPKhPlrTqvCXR6kBpGmvDefEgdPWGR7KSYkoKsu4yrowZK4ScbvyQjxSJjB7Ak2qMmNYhBiIMbXgSwW4WnLP3DhXscoT7hNbA2ekMSeZOzpe4CCxGQQp',
      tokens: [0, 0, 0, 0],
      isAi: true,
    },
  ]);

  // Handle rolling dice
  const handleRollDice = () => {
    if (isRolling || winner) return;

    sounds.playDiceRoll();
    setIsRolling(true);

    setTimeout(() => {
      const rolled = Math.floor(Math.random() * 6) + 1;
      setDiceValue(rolled);
      setIsRolling(false);

      const activeP = players[currentTurn];

      // Auto move rule for AI or check available moves
      if (activeP.isAi) {
        handleAiMove(rolled, currentTurn);
      } else {
        // Player turn
        setGameLog((prev) => [
          `شما تاس ریختید: ${rolled}! برای حرکت روی مهره خود کلیک کنید.`,
          ...prev.slice(0, 5),
        ]);
      }
    }, 600);
  };

  // Move token
  const handleMoveToken = (playerIdx: number, tokenIdx: number) => {
    if (playerIdx !== currentTurn || isRolling || winner) return;

    const currentP = players[playerIdx];
    const currentPos = currentP.tokens[tokenIdx];

    if (currentPos === 0 && diceValue !== 6) {
      setGameLog((prev) => ['برای خروج از خانه به عدد ۶ نیاز دارید!', ...prev.slice(0, 5)]);
      return;
    }

    sounds.playClick();
    const newPlayers = [...players];
    let nextPos = currentPos === 0 ? 1 : currentPos + diceValue;
    if (nextPos > 57) nextPos = 57;

    newPlayers[playerIdx].tokens[tokenIdx] = nextPos;
    setPlayers(newPlayers);

    setGameLog((prev) => [
      `${currentP.name} مهره ${tokenIdx + 1} را ${diceValue} خانه جلو برد.`,
      ...prev.slice(0, 5),
    ]);

    // Check victory
    if (nextPos >= 52) {
      sounds.playCoin();
      setWinner(currentP.name);
      onEarnCoins(250);
      setGameLog((prev) => [`🎉 تبریک! ${currentP.name} برنده مسابقه شد! +۲۵۰ DC پاداش.`, ...prev]);
      return;
    }

    // Next turn
    if (diceValue !== 6) {
      const nextTurn = (currentTurn + 1) % players.length;
      setCurrentTurn(nextTurn);
    }
  };

  // AI bot turns
  const handleAiMove = (rolled: number, pIdx: number) => {
    const aiPlayer = players[pIdx];
    setTimeout(() => {
      const newPlayers = [...players];
      // Pick first token on board or exit home if rolled 6
      let chosenToken = -1;
      for (let i = 0; i < aiPlayer.tokens.length; i++) {
        if (aiPlayer.tokens[i] > 0) {
          chosenToken = i;
          break;
        }
      }
      if (chosenToken === -1 && rolled === 6) {
        chosenToken = 0;
      }

      if (chosenToken !== -1) {
        const cur = aiPlayer.tokens[chosenToken];
        let nxt = cur === 0 ? 1 : cur + rolled;
        if (nxt > 57) nxt = 57;
        newPlayers[pIdx].tokens[chosenToken] = nxt;
        setPlayers(newPlayers);
        setGameLog((prev) => [
          `${aiPlayer.name} تاس ${rolled} ریخت و مهره‌اش حرکت کرد.`,
          ...prev.slice(0, 5),
        ]);

        if (nxt >= 52) {
          setWinner(aiPlayer.name);
          return;
        }
      } else {
        setGameLog((prev) => [
          `${aiPlayer.name} تاس ${rolled} ریخت (حرکتی نداشت).`,
          ...prev.slice(0, 5),
        ]);
      }

      // Next turn
      if (rolled !== 6) {
        const nextTurn = (pIdx + 1) % players.length;
        setCurrentTurn(nextTurn);
      }
    }, 800);
  };

  // Trigger AI turn if not player
  useEffect(() => {
    if (currentTurn !== 0 && !isRolling && !winner) {
      const timer = setTimeout(() => {
        handleRollDice();
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [currentTurn, isRolling, winner]);

  return (
    <div className="glass-panel p-4 md:p-6 rounded-2xl border border-white/60 dark:border-white/10 shadow-2xl flex flex-col gap-5 select-none animate-slide-up">
      {/* Header */}
      <div className="flex justify-between items-center pb-3 border-b border-black/10 dark:border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#00d2ff] to-[#00677f] flex items-center justify-center text-white shadow-lg">
            <span className="material-symbols-outlined text-2xl">casino</span>
          </div>
          <div>
            <h2 className="font-extrabold text-lg md:text-xl text-[#191c1e] dark:text-white">
              Neon Ludo Strike 3D
            </h2>
            <p className="text-xs text-[#3c494e] dark:text-[#bfc8cc]">
              مسابقه ۴ نفره آنلاین - جایزه برنده: ۲۵۰ DC
            </p>
          </div>
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-black/5 dark:bg-white/10 text-xs font-bold hover:bg-black/10 cursor-pointer"
          >
            خروج از بازی
          </button>
        )}
      </div>

      {/* Main Board Arena */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        {/* Left/Center Neon Ludo Board Canvas representation */}
        <div className="lg:col-span-8 flex flex-col items-center justify-center">
          <div className="relative w-full max-w-md aspect-square rounded-2xl bg-gradient-to-br from-[#101418] to-[#181d22] p-4 border-2 border-[#00d2ff]/40 shadow-[0_0_30px_rgba(0,210,255,0.2)] flex flex-col justify-between">
            {/* 4 Player Corners */}
            <div className="flex justify-between items-center">
              {/* Cyan Player (User) */}
              <div
                className={`p-2.5 rounded-xl border transition-all ${
                  currentTurn === 0
                    ? 'ring-2 ring-[#00d2ff] bg-[#00d2ff]/20 shadow-[0_0_15px_rgba(0,210,255,0.4)]'
                    : 'border-white/10 bg-black/40'
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <img
                    className="w-6 h-6 rounded-full object-cover"
                    src={players[0].avatar}
                    alt="P1"
                  />
                  <span className="text-[11px] font-bold text-[#00d2ff]">{players[0].name}</span>
                </div>
                <div className="flex gap-2">
                  {players[0].tokens.map((pos, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleMoveToken(0, idx)}
                      className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs text-black transition-all cursor-pointer ${
                        pos === 0
                          ? 'bg-[#00d2ff]/40 border border-[#00d2ff]'
                          : 'bg-[#00d2ff] shadow-[0_0_10px_#00d2ff] scale-110'
                      }`}
                    >
                      {pos === 0 ? 'H' : pos}
                    </button>
                  ))}
                </div>
              </div>

              {/* Magenta Player (Alex Nova) */}
              <div
                className={`p-2.5 rounded-xl border transition-all ${
                  currentTurn === 1
                    ? 'ring-2 ring-[#bb00fc] bg-[#bb00fc]/20 shadow-[0_0_15px_rgba(187,0,252,0.4)]'
                    : 'border-white/10 bg-black/40'
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <img
                    className="w-6 h-6 rounded-full object-cover"
                    src={players[1].avatar}
                    alt="P2"
                  />
                  <span className="text-[11px] font-bold text-[#bb00fc]">{players[1].name}</span>
                </div>
                <div className="flex gap-2">
                  {players[1].tokens.map((pos, idx) => (
                    <div
                      key={idx}
                      className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs text-white ${
                        pos === 0
                          ? 'bg-[#bb00fc]/40 border border-[#bb00fc]'
                          : 'bg-[#bb00fc] shadow-[0_0_10px_#bb00fc]'
                      }`}
                    >
                      {pos === 0 ? 'H' : pos}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Center Neon Pathway & Dice Hub */}
            <div className="flex flex-col items-center justify-center py-4 relative">
              <div className="absolute inset-0 flex items-center justify-center opacity-30">
                <div className="w-32 h-32 rounded-full border border-dashed border-[#00d2ff] animate-spin" style={{ animationDuration: '20s' }}></div>
              </div>

              {/* 3D Visual Dice Button */}
              <div className="relative z-10 flex flex-col items-center gap-2">
                <button
                  id="btn-roll-dice"
                  onClick={handleRollDice}
                  disabled={isRolling || currentTurn !== 0 || !!winner}
                  className={`w-20 h-20 rounded-2xl bg-gradient-to-tr from-[#191c1e] to-[#2d3133] border-2 border-white/20 shadow-2xl flex flex-col items-center justify-center text-3xl font-black transition-all cursor-pointer active:scale-95 ${
                    isRolling ? 'animate-dice ring-4 ring-[#00d2ff]' : ''
                  } ${
                    currentTurn === 0 && !winner
                      ? 'ring-2 ring-[#00d2ff] shadow-[0_0_20px_rgba(0,210,255,0.6)] hover:scale-105'
                      : 'opacity-80'
                  }`}
                >
                  <span className="text-gradient font-extrabold">{diceValue}</span>
                  <span className="text-[9px] text-[#bfc8cc] font-medium mt-0.5">
                    {isRolling ? 'در حال چرخش...' : currentTurn === 0 ? 'پرتاب کن!' : 'نوبت حریف'}
                  </span>
                </button>
              </div>
            </div>

            {/* Bottom 2 Player Corners */}
            <div className="flex justify-between items-center">
              {/* Yellow Player (TigerClaw) */}
              <div
                className={`p-2.5 rounded-xl border transition-all ${
                  currentTurn === 3
                    ? 'ring-2 ring-[#f0b232] bg-[#f0b232]/20 shadow-[0_0_15px_rgba(240,178,50,0.4)]'
                    : 'border-white/10 bg-black/40'
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <img
                    className="w-6 h-6 rounded-full object-cover"
                    src={players[3].avatar}
                    alt="P4"
                  />
                  <span className="text-[11px] font-bold text-[#f0b232]">{players[3].name}</span>
                </div>
                <div className="flex gap-2">
                  {players[3].tokens.map((pos, idx) => (
                    <div
                      key={idx}
                      className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs text-black ${
                        pos === 0
                          ? 'bg-[#f0b232]/40 border border-[#f0b232]'
                          : 'bg-[#f0b232] shadow-[0_0_10px_#f0b232]'
                      }`}
                    >
                      {pos === 0 ? 'H' : pos}
                    </div>
                  ))}
                </div>
              </div>

              {/* Green Player (CyberKid) */}
              <div
                className={`p-2.5 rounded-xl border transition-all ${
                  currentTurn === 2
                    ? 'ring-2 ring-[#23a559] bg-[#23a559]/20 shadow-[0_0_15px_rgba(35,165,89,0.4)]'
                    : 'border-white/10 bg-black/40'
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <img
                    className="w-6 h-6 rounded-full object-cover"
                    src={players[2].avatar}
                    alt="P3"
                  />
                  <span className="text-[11px] font-bold text-[#23a559]">{players[2].name}</span>
                </div>
                <div className="flex gap-2">
                  {players[2].tokens.map((pos, idx) => (
                    <div
                      key={idx}
                      className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs text-white ${
                        pos === 0
                          ? 'bg-[#23a559]/40 border border-[#23a559]'
                          : 'bg-[#23a559] shadow-[0_0_10px_#23a559]'
                      }`}
                    >
                      {pos === 0 ? 'H' : pos}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Match Feed & Game Status */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          {/* Winner Banner */}
          {winner && (
            <div className="p-4 rounded-2xl bg-gradient-to-r from-[#f59e0b] to-[#ec4899] text-white shadow-xl text-center animate-bounce">
              <span className="material-symbols-outlined text-3xl">emoji_events</span>
              <h3 className="font-extrabold text-lg mt-1">برنده: {winner}!</h3>
              <p className="text-xs mt-1">پاداش مسابقه به کیف پول شما اضافه شد (+۲۵۰ DC).</p>
              <button
                onClick={() => {
                  setWinner(null);
                  setCurrentTurn(0);
                  setPlayers((prev) =>
                    prev.map((p) => ({ ...p, tokens: [1, 0, 0, 0] }))
                  );
                }}
                className="mt-3 px-4 py-1.5 bg-white text-black font-bold text-xs rounded-xl shadow cursor-pointer hover:opacity-90"
              >
                بازی مجدد
              </button>
            </div>
          )}

          {/* Current Turn Badge */}
          <div className="p-4 rounded-xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 flex items-center gap-3">
            <div className="relative">
              <img
                className="w-10 h-10 rounded-full object-cover border-2"
                style={{ borderColor: players[currentTurn].color }}
                src={players[currentTurn].avatar}
                alt="Current"
              />
              <span className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-[#23a559] border-2 border-white animate-pulse"></span>
            </div>
            <div>
              <p className="text-xs text-[#3c494e] dark:text-[#bfc8cc]">نوبت فعلی پرتاب:</p>
              <h4
                className="font-bold text-sm"
                style={{ color: players[currentTurn].color }}
              >
                {players[currentTurn].name}
              </h4>
            </div>
          </div>

          {/* Real-time Match Logs */}
          <div className="p-4 rounded-xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 flex flex-col gap-2">
            <h4 className="text-xs font-bold text-[#191c1e] dark:text-white flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-[#00d2ff]">history</span>
              گزارش زنده راند
            </h4>
            <div className="flex flex-col gap-1.5 max-h-48 overflow-y-auto text-xs text-[#3c494e] dark:text-[#bfc8cc] hide-scrollbar">
              {gameLog.map((log, i) => (
                <div key={i} className="p-1.5 rounded-lg bg-black/5 dark:bg-white/5 text-[11px] leading-relaxed">
                  {log}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
