import React, { useState } from 'react';
import { Tournament, UserProfile } from '../types';
import { sounds } from '../utils/audio';

interface TournamentsViewProps {
  tournaments: Tournament[];
  user: UserProfile;
  onRegister: (tournamentId: string, fee: number) => void;
  onSelectGame: (gameId: string) => void;
}

export const TournamentsView: React.FC<TournamentsViewProps> = ({
  tournaments,
  user,
  onRegister,
  onSelectGame,
}) => {
  const [registeredMap, setRegisteredMap] = useState<{ [id: string]: boolean }>({});
  const [selectedTour, setSelectedTour] = useState<Tournament | null>(null);

  const handleJoin = (tour: Tournament) => {
    if (user.dcCoins < tour.entryFee) return;
    sounds.playCoin();
    setRegisteredMap((prev) => ({ ...prev, [tour.id]: true }));
    onRegister(tour.id, tour.entryFee);
    setSelectedTour(null);
  };

  return (
    <div className="flex flex-col gap-6 pb-12 animate-slide-up">
      {/* Header Banner */}
      <div className="glass-panel p-6 md:p-8 rounded-2xl border border-white/50 dark:border-white/10 relative overflow-hidden flex flex-col md:flex-row justify-between items-center gap-6 shadow-xl">
        <div className="relative z-10 flex flex-col gap-2 text-right">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#f59e0b] animate-ping"></span>
            <span className="text-xs font-bold text-[#f59e0b] uppercase tracking-wider">
              لیگ و تورنمنت‌های هفتگی
            </span>
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-[#191c1e] dark:text-white">
            جام قهرمانان DicoPick
          </h1>
          <p className="text-xs md:text-sm text-[#3c494e] dark:text-[#bfc8cc] max-w-lg leading-relaxed">
            در مسابقات هیجان‌انگیز شرکت کنید، حریفان را شکست دهید و سهم خود را از صندوق جوایز بزرگ
            DC ببرید!
          </p>
        </div>

        <div className="flex items-center gap-4 bg-black/5 dark:bg-white/5 p-4 rounded-2xl border border-black/10 dark:border-white/10">
          <div className="text-right">
            <span className="text-[11px] text-[#3c494e] dark:text-[#bfc8cc] block">
              کل جوایز این هفته:
            </span>
            <span className="font-extrabold text-xl text-gradient-gold">۷۵,۰۰۰ DC</span>
          </div>
          <span className="material-symbols-outlined text-4xl text-[#f59e0b]">emoji_events</span>
        </div>
      </div>

      {/* Tournaments Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {tournaments.map((tour) => {
          const isRegistered = registeredMap[tour.id];
          return (
            <div
              key={tour.id}
              className="glass-panel p-6 rounded-2xl border border-white/50 dark:border-white/10 flex flex-col justify-between gap-5 group hover:shadow-2xl transition-all"
            >
              <div className="flex flex-col gap-4">
                <div className="relative aspect-video w-full rounded-xl overflow-hidden border border-white/20">
                  <img
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    src={tour.gameThumbnail}
                    alt={tour.title}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                  <div className="absolute top-3 right-3 bg-gradient-to-r from-[#f59e0b] to-[#ec4899] text-white text-xs font-black px-3 py-1 rounded-lg shadow-lg">
                    جایزه: {tour.prizePool}
                  </div>
                  <div className="absolute bottom-3 right-3 text-right">
                    <h3 className="text-white font-extrabold text-lg drop-shadow-md">
                      {tour.title}
                    </h3>
                    <span className="text-xs text-white/80">{tour.startTime}</span>
                  </div>
                </div>

                {/* Info Pills */}
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-black/5 dark:bg-white/5 p-2.5 rounded-xl text-right">
                    <span className="text-[10px] text-[#3c494e]/70 dark:text-[#bfc8cc]/70 block">
                      هزینه ورودی:
                    </span>
                    <span className="font-bold text-[#bb00fc] dark:text-[#ecb2ff]">
                      {tour.entryFee === 0 ? 'رایگان' : `${tour.entryFee} DC`}
                    </span>
                  </div>
                  <div className="bg-black/5 dark:bg-white/5 p-2.5 rounded-xl text-right">
                    <span className="text-[10px] text-[#3c494e]/70 dark:text-[#bfc8cc]/70 block">
                      ظرفیت تکمیل شده:
                    </span>
                    <span className="font-bold text-[#23a559]">
                      {tour.registeredPlayers + (isRegistered ? 1 : 0)} / {tour.maxPlayers} بازیکن
                    </span>
                  </div>
                </div>

                {/* Rules List */}
                <div className="flex flex-col gap-1 text-[11px] text-[#3c494e] dark:text-[#bfc8cc]">
                  <span className="font-bold text-[#191c1e] dark:text-white">قوانین مسابقه:</span>
                  {tour.rules.map((rule, idx) => (
                    <div key={idx} className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#00d2ff]"></span>
                      <span>{rule}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 pt-2 border-t border-black/10 dark:border-white/10">
                <button
                  onClick={() => {
                    sounds.playClick();
                    setSelectedTour(tour);
                  }}
                  disabled={isRegistered}
                  className={`flex-1 py-3 rounded-xl font-bold text-xs shadow-md transition-all cursor-pointer ${
                    isRegistered
                      ? 'bg-[#23a559]/20 text-[#23a559] border border-[#23a559]/40'
                      : 'bg-gradient-to-r from-[#00677f] to-[#9500ca] text-white hover:scale-105'
                  }`}
                >
                  {isRegistered ? '✓ شما ثبت‌نام کرده‌اید' : 'ثبت‌نام در مسابقه'}
                </button>

                <button
                  onClick={() => {
                    sounds.playClick();
                    onSelectGame(tour.game.includes('Ludo') ? 'game-ludo' : 'game-aero');
                  }}
                  className="px-4 py-3 rounded-xl bg-black/5 dark:bg-white/10 hover:bg-black/10 text-[#191c1e] dark:text-white font-bold text-xs cursor-pointer"
                  title="تمرین قبل مسابقه"
                >
                  تمرین بازی
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Confirmation Join Modal */}
      {selectedTour && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#191c1e] p-6 rounded-2xl max-w-sm w-full border border-white/20 shadow-2xl animate-slide-up text-right">
            <h3 className="font-bold text-lg text-[#191c1e] dark:text-white mb-2 flex items-center gap-2">
              <span className="material-symbols-outlined text-[#f59e0b]">emoji_events</span>
              ثبت‌نام در {selectedTour.title}
            </h3>
            <p className="text-xs text-[#3c494e] dark:text-[#bfc8cc] mb-4 leading-relaxed">
              هزینه ورودی {selectedTour.entryFee} DC از موجودی شما کسر خواهد شد. آیا مایل به تایید
              ثبت‌نام هستید؟
            </p>

            <div className="bg-black/5 dark:bg-white/5 p-3 rounded-xl mb-4 text-xs">
              <div className="flex justify-between py-1">
                <span>موجودی فعلی شما:</span>
                <span className="font-bold">{user.dcCoins} DC</span>
              </div>
              <div className="flex justify-between py-1 text-[#bb00fc]">
                <span>هزینه ورودی:</span>
                <span className="font-bold">-{selectedTour.entryFee} DC</span>
              </div>
            </div>

            <div className="flex gap-2 justify-end">
              <button
                onClick={() => setSelectedTour(null)}
                className="px-4 py-2 rounded-xl text-xs text-[#3c494e] dark:text-white hover:bg-black/5 cursor-pointer"
              >
                انصراف
              </button>
              <button
                onClick={() => handleJoin(selectedTour)}
                disabled={user.dcCoins < selectedTour.entryFee}
                className="px-6 py-2 rounded-xl bg-gradient-to-r from-[#00677f] to-[#9500ca] text-white text-xs font-bold shadow-md cursor-pointer hover:opacity-90 disabled:opacity-50"
              >
                تایید و ثبت‌نام
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
