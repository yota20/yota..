import React, { useState } from 'react';
import { ActiveTab, UserProfile } from '../types';
import { sounds } from '../utils/audio';

interface TopNavbarProps {
  activeTab: ActiveTab;
  user: UserProfile;
  onOpenWallet: () => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  onToggleSound: () => void;
  soundEnabled: boolean;
  onOpenMobileMenu?: () => void;
}

export const TopNavbar: React.FC<TopNavbarProps> = ({
  activeTab,
  user,
  onOpenWallet,
  isDarkMode,
  onToggleTheme,
  onToggleSound,
  soundEnabled,
  onOpenMobileMenu,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [unreadCount, setUnreadCount] = useState(2);

  const getTabTitle = () => {
    switch (activeTab) {
      case 'discover':
        return { title: 'کشف کردن', icon: 'explore' };
      case 'live':
        return { title: 'پخش زنده و استریم', icon: 'live_tv' };
      case 'tournaments':
        return { title: 'مسابقات و جوایز', icon: 'emoji_events' };
      case 'games':
        return { title: 'بازی‌های متاورس', icon: 'sports_esports' };
      case 'wallet':
        return { title: 'کیف پول و DicoCoins', icon: 'account_balance_wallet' };
      case 'profile':
        return { title: 'پروفایل کاربری', icon: 'person' };
      default:
        return { title: 'کشف کردن', icon: 'explore' };
    }
  };

  const { title, icon } = getTabTitle();

  const notifications = [
    {
      id: 'n1',
      title: 'اینوایت بازی Ludo',
      desc: 'CyberKid شما را به یک مسابقه Ludo دعوت کرد.',
      time: '۲ دقیقه پیش',
      icon: 'sports_esports',
      isNew: true,
    },
    {
      id: 'n2',
      title: 'شروع استریم Alex Nova',
      desc: 'فینال جام بزرگ Neon Ludo آغاز شد!',
      time: '۱۰ دقیقه پیش',
      icon: 'live_tv',
      isNew: true,
    },
    {
      id: 'n3',
      title: 'پاداش روزانه آماده است',
      desc: '۱۰۰ DC هدیه امروز خود را دریافت کنید.',
      time: '۱ ساعت پیش',
      icon: 'redeem',
      isNew: false,
    },
  ];

  return (
    <nav
      id="top-navbar"
      className="fixed top-0 left-0 right-0 md:right-[336px] z-30 h-16 bg-[#f7f9fb]/70 dark:bg-[#111416]/80 backdrop-blur-md border-b border-black/10 dark:border-white/10 flex justify-between items-center px-4 md:px-6 select-none"
    >
      {/* Tab Title & Mobile Menu Trigger */}
      <div className="flex items-center gap-3">
        {onOpenMobileMenu && (
          <button
            onClick={onOpenMobileMenu}
            className="md:hidden p-2 rounded-xl bg-black/5 dark:bg-white/5 text-[#191c1e] dark:text-[#e0e3e5]"
            title="منو"
          >
            <span className="material-symbols-outlined text-[22px]">menu</span>
          </button>
        )}

        <h2 className="text-lg md:text-xl font-bold text-[#191c1e] dark:text-[#e0e3e5] flex items-center gap-2">
          <span className="material-symbols-outlined text-[#00677f] dark:text-[#00d2ff] text-2xl">
            {icon}
          </span>
          <span>{title}</span>
        </h2>
      </div>

      {/* Top Actions & Wallet Pill */}
      <div className="flex items-center gap-2 md:gap-3">
        {/* Sound FX Toggle */}
        <button
          onClick={() => {
            onToggleSound();
            sounds.playClick();
          }}
          className={`p-2 rounded-xl transition-all cursor-pointer ${
            soundEnabled
              ? 'text-[#00677f] dark:text-[#00d2ff] bg-black/5 dark:bg-white/5'
              : 'text-[#3c494e]/50 dark:text-[#bfc8cc]/40 bg-black/5 dark:bg-white/5'
          }`}
          title={soundEnabled ? 'صداها فعال است' : 'صداها غیرفعال است'}
        >
          <span className="material-symbols-outlined text-[20px]">
            {soundEnabled ? 'volume_up' : 'volume_off'}
          </span>
        </button>

        {/* Dark/Light Mode Switch */}
        <button
          onClick={() => {
            sounds.playClick();
            onToggleTheme();
          }}
          className="p-2 rounded-xl bg-black/5 dark:bg-white/5 text-[#191c1e] dark:text-[#e0e3e5] hover:bg-black/10 dark:hover:bg-white/10 transition-colors cursor-pointer"
          title={isDarkMode ? 'حالت روشن' : 'حالت تاریک'}
        >
          <span className="material-symbols-outlined text-[20px]">
            {isDarkMode ? 'light_mode' : 'dark_mode'}
          </span>
        </button>

        {/* Notification Bell */}
        <div className="relative">
          <button
            id="btn-notifications"
            onClick={() => {
              sounds.playClick();
              setShowNotifications(!showNotifications);
              if (unreadCount > 0) setUnreadCount(0);
            }}
            className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors relative cursor-pointer"
            title="اعلان‌ها"
          >
            <span className="material-symbols-outlined text-[#00677f] dark:text-[#00d2ff] text-[22px]">
              notifications
            </span>
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-[#f7f9fb] dark:border-[#111416] animate-pulse"></span>
            )}
          </button>

          {/* Notifications Dropdown */}
          {showNotifications && (
            <div className="absolute left-0 mt-3 w-80 bg-white dark:bg-[#191c1e] rounded-2xl shadow-2xl border border-black/10 dark:border-white/10 p-3 z-50 animate-slide-up">
              <div className="flex justify-between items-center pb-2 mb-2 border-b border-black/10 dark:border-white/10">
                <span className="font-bold text-sm text-[#191c1e] dark:text-white">
                  اعلان‌های سیستم
                </span>
                <span className="text-[11px] text-[#00677f] dark:text-[#00d2ff]">همه‌خوانده شد</span>
              </div>
              <div className="flex flex-col gap-2 max-h-64 overflow-y-auto hide-scrollbar">
                {notifications.map((n) => (
                  <div
                    key={n.id}
                    className="p-2.5 rounded-xl bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 transition-all flex gap-3 text-right"
                  >
                    <div className="w-8 h-8 rounded-lg bg-[#00677f]/10 dark:bg-[#00d2ff]/20 text-[#00677f] dark:text-[#00d2ff] flex items-center justify-center shrink-0">
                      <span className="material-symbols-outlined text-[18px]">{n.icon}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center">
                        <p className="text-xs font-bold text-[#191c1e] dark:text-white truncate">
                          {n.title}
                        </p>
                        <span className="text-[9px] text-[#3c494e]/70 dark:text-[#bfc8cc]/70">
                          {n.time}
                        </span>
                      </div>
                      <p className="text-[11px] text-[#3c494e] dark:text-[#bfc8cc] mt-0.5 line-clamp-2">
                        {n.desc}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* DicoCoin Balance Pill (Matching screenshot: ۱,۲۵۰ DC) */}
        <button
          id="btn-top-wallet"
          onClick={() => {
            sounds.playCoin();
            onOpenWallet();
          }}
          className="px-3.5 py-1.5 rounded-xl bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 transition-all flex items-center gap-2 text-sm font-bold border border-black/10 dark:border-white/10 cursor-pointer shadow-sm hover:scale-105 active:scale-95"
          title="مشاهده کیف پول و دریافت سکه رایگان"
        >
          <span className="material-symbols-outlined text-[#bb00fc] text-[18px] animate-pulse">
            diamond
          </span>
          <span className="text-[#191c1e] dark:text-[#e0e3e5]">
            {user.dcCoins.toLocaleString('fa-IR')} DC
          </span>
        </button>
      </div>
    </nav>
  );
};
