import React, { useState } from 'react';
import { GameItem } from '../types';
import { NeonLudoGame } from './games/NeonLudoGame';
import { AeroSprintGame } from './games/AeroSprintGame';
import { sounds } from '../utils/audio';

interface GamesViewProps {
  games: GameItem[];
  activeGameId: string | null;
  onSelectGame: (gameId: string) => void;
  onEarnCoins: (amount: number) => void;
}

export const GamesView: React.FC<GamesViewProps> = ({
  games,
  activeGameId,
  onSelectGame,
  onEarnCoins,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'همه بازی‌ها' },
    { id: 'Board Game', label: 'تخته و رومیزی' },
    { id: 'Cyber Arcade', label: 'آرکید سایبری' },
    { id: 'multiplayer', label: 'چند نفره آنلاین' },
  ];

  const filteredGames = games.filter((g) =>
    activeCategory === 'all' ? true : g.category.includes(activeCategory) || activeCategory === 'multiplayer'
  );

  return (
    <div className="flex flex-col gap-6 pb-12 animate-slide-up">
      {/* If a game is active, render the playable interactive game engine */}
      {activeGameId === 'game-ludo' && (
        <NeonLudoGame
          onEarnCoins={onEarnCoins}
          onClose={() => onSelectGame('')}
        />
      )}

      {activeGameId === 'game-aero' && (
        <AeroSprintGame
          onEarnCoins={onEarnCoins}
          onClose={() => onSelectGame('')}
        />
      )}

      {/* Header Banner */}
      {!activeGameId && (
        <div className="glass-panel p-6 md:p-8 rounded-2xl border border-white/50 dark:border-white/10 relative overflow-hidden flex flex-col md:flex-row justify-between items-center gap-6 shadow-lg">
          <div className="relative z-10 flex flex-col gap-2 text-right">
            <span className="text-xs font-bold text-[#00677f] dark:text-[#00d2ff] uppercase tracking-wider">
              مرکز بازی‌های اجتماعی متاورس
            </span>
            <h1 className="text-2xl md:text-3xl font-extrabold text-[#191c1e] dark:text-white">
              انتخاب بازی و رقابت آنلاین
            </h1>
            <p className="text-xs md:text-sm text-[#3c494e] dark:text-[#bfc8cc] max-w-lg leading-relaxed">
              با دوستان خود در اتاق‌های چند نفره بازی کنید، رنک کسب کنید و سکه‌های DC به دست آورید!
            </p>
          </div>

          <div className="flex gap-3">
            <button
              onClick={() => {
                sounds.playCoin();
                onSelectGame('game-ludo');
              }}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#00677f] to-[#9500ca] text-white font-bold text-xs shadow-lg hover:scale-105 transition-all cursor-pointer"
            >
              شروع سریع Neon Ludo
            </button>
            <button
              onClick={() => {
                sounds.playBoost();
                onSelectGame('game-aero');
              }}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#00d2ff] to-[#bb00fc] text-white font-bold text-xs shadow-lg hover:scale-105 transition-all cursor-pointer"
            >
              شروع Aero Sprint
            </button>
          </div>
        </div>
      )}

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 hide-scrollbar">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => {
              sounds.playClick();
              setActiveCategory(cat.id);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeCategory === cat.id
                ? 'bg-[#00677f] dark:bg-[#00d2ff] text-white dark:text-black shadow-md'
                : 'bg-black/5 dark:bg-white/5 text-[#3c494e] dark:text-[#bfc8cc] hover:bg-black/10 dark:hover:bg-white/10'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Games Catalog Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredGames.map((game) => (
          <div
            key={game.id}
            className={`glass-panel p-5 rounded-2xl border transition-all duration-300 hover:shadow-2xl flex flex-col justify-between group ${
              activeGameId === game.id
                ? 'border-[#00d2ff] ring-2 ring-[#00d2ff]/40 shadow-xl'
                : 'border-white/50 dark:border-white/10 hover:border-[#00d2ff]/40'
            }`}
          >
            <div className="flex flex-col gap-4">
              <div className="relative aspect-video w-full rounded-xl overflow-hidden border border-white/20">
                <img
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  src={game.thumbnail}
                  alt={game.title}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                <div className="absolute top-3 left-3 bg-black/60 backdrop-blur text-white text-xs font-bold px-2.5 py-1 rounded-lg flex items-center gap-1 border border-white/10">
                  <span>⭐</span>
                  <span>{game.rating}</span>
                </div>
                <div className="absolute bottom-3 right-3 text-right">
                  <span className="text-white font-extrabold text-base drop-shadow-md">
                    {game.title}
                  </span>
                  <span className="text-xs text-white/80 block">{game.persianTitle}</span>
                </div>
              </div>

              <div>
                <p className="text-xs text-[#3c494e] dark:text-[#bfc8cc] leading-relaxed">
                  {game.description}
                </p>
                <div className="flex gap-2 mt-3">
                  <span className="text-[10px] bg-black/5 dark:bg-white/10 text-[#3c494e] dark:text-[#bfc8cc] px-2 py-0.5 rounded-md font-semibold">
                    {game.category}
                  </span>
                  <span className="text-[10px] bg-[#23a559]/10 text-[#23a559] px-2 py-0.5 rounded-md font-semibold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#23a559] animate-pulse"></span>
                    {game.playersOnline.toLocaleString('fa-IR')} بازیکن آنلاین
                  </span>
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center mt-5 pt-3 border-t border-black/10 dark:border-white/10">
              <span className="text-xs font-bold text-[#bb00fc] dark:text-[#ecb2ff]">
                پاداش برد: تا ۲۵۰ DC
              </span>
              <button
                id={`btn-play-${game.id}`}
                onClick={() => {
                  sounds.playCoin();
                  onSelectGame(game.id);
                }}
                className={`px-6 py-2.5 rounded-xl text-white text-xs font-bold bg-gradient-to-r ${game.colorGradient} hover:scale-105 shadow-md transition-all cursor-pointer`}
              >
                {activeGameId === game.id ? 'درحال اجرا' : 'اجرای بازی'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
