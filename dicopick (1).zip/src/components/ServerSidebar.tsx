import React from 'react';
import { ActiveTab } from '../types';
import { sounds } from '../utils/audio';

interface ServerSidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onSelectGame?: (gameId: string) => void;
  activeGameId?: string | null;
}

export const ServerSidebar: React.FC<ServerSidebarProps> = ({
  activeTab,
  setActiveTab,
  onSelectGame,
  activeGameId,
}) => {
  return (
    <aside
      id="server-sidebar"
      className="fixed right-0 top-0 h-full w-[72px] z-50 bg-[#f7f9fb]/40 dark:bg-[#111416]/70 backdrop-blur-3xl border-l border-white/20 dark:border-white/10 flex flex-col items-center py-4 gap-4 select-none"
    >
      {/* Home Icon */}
      <div className="relative group">
        <button
          id="btn-server-home"
          onClick={() => {
            sounds.playClick();
            setActiveTab('discover');
            if (onSelectGame) onSelectGame('');
          }}
          className={`relative w-12 h-12 rounded-[24px] hover:rounded-[16px] transition-all duration-300 flex items-center justify-center cursor-pointer ${
            activeTab === 'discover' && !activeGameId
              ? 'rounded-[16px] bg-gradient-to-tr from-[#00677f] to-[#9500ca] shadow-[0_0_18px_rgba(187,0,252,0.5)] scale-105'
              : 'bg-gradient-to-tr from-[#00677f] to-[#9500ca] hover:shadow-[0_0_15px_rgba(187,0,252,0.4)]'
          }`}
          title="خانه"
        >
          <span className="material-symbols-outlined text-white text-[24px]" style={{ fontVariationSettings: "'FILL' 1" }}>
            home
          </span>
        </button>

        {/* Active Pill Indicator */}
        <div
          className={`absolute -right-2 top-1/2 -translate-y-1/2 w-1 bg-white rounded-r-full transition-all duration-200 ${
            activeTab === 'discover' && !activeGameId ? 'h-8 block' : 'h-2 group-hover:h-5 hidden group-hover:block'
          }`}
        />

        {/* Tooltip */}
        <div className="absolute right-full mr-3 top-1/2 -translate-y-1/2 px-2.5 py-1 bg-[#191c1e] text-white text-xs font-semibold rounded-md shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-50">
          خانه و دیسکاور
        </div>
      </div>

      <div className="w-8 h-[2px] bg-black/10 dark:bg-white/20 rounded-full my-1"></div>

      {/* Game 1: Neon Ludo Strike */}
      <div className="relative group">
        <button
          id="btn-server-ludo"
          onClick={() => {
            sounds.playClick();
            setActiveTab('games');
            if (onSelectGame) onSelectGame('game-ludo');
          }}
          className={`w-12 h-12 rounded-[24px] hover:rounded-[16px] transition-all duration-300 overflow-hidden cursor-pointer relative ${
            activeGameId === 'game-ludo'
              ? 'rounded-[16px] ring-2 ring-[#00d2ff] shadow-[0_0_16px_rgba(0,210,255,0.6)]'
              : 'bg-white/20 hover:bg-[#00d2ff]/20'
          }`}
          title="Neon Ludo Strike"
        >
          <img
            className="w-full h-full object-cover opacity-85 group-hover:opacity-100 transition-opacity"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuBd9BFgytr7FWR1uJ6Rk53KnjGyEquhaX3oegB9L-IPyqu91MXcohM6bK9CpbuI-DDgMaad7zt9_4D18wWDL3Gzr6ehi93DHgobtCd6RD59v-VHm7MG6AiuqULbk9qSP5QmgFqO9Z5APWoowfDP4V1gkMPVFi5np1YyLSdmASpC8084UpTt7UHO-EwuzTo1cJkXahPZeaIRznQwczSJGJ64hIdkQL3cqFJXizl_TxnmqQb7LgIXmCzx"
            alt="Neon Ludo Strike"
          />
        </button>

        <div
          className={`absolute -right-2 top-1/2 -translate-y-1/2 w-1 bg-[#00d2ff] rounded-r-full transition-all duration-200 ${
            activeGameId === 'game-ludo' ? 'h-8 block' : 'h-2 group-hover:h-5 hidden group-hover:block'
          }`}
        />

        <div className="absolute right-full mr-3 top-1/2 -translate-y-1/2 px-2.5 py-1 bg-[#191c1e] text-white text-xs font-semibold rounded-md shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-50 flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-[#00d2ff]"></span>
          Neon Ludo Strike
        </div>
      </div>

      {/* Game 2: Aero Sprint */}
      <div className="relative group">
        <button
          id="btn-server-aero"
          onClick={() => {
            sounds.playClick();
            setActiveTab('games');
            if (onSelectGame) onSelectGame('game-aero');
          }}
          className={`w-12 h-12 rounded-[24px] hover:rounded-[16px] transition-all duration-300 overflow-hidden cursor-pointer relative ${
            activeGameId === 'game-aero'
              ? 'rounded-[16px] ring-2 ring-[#bb00fc] shadow-[0_0_16px_rgba(187,0,252,0.6)]'
              : 'bg-white/20 hover:bg-[#bb00fc]/20'
          }`}
          title="Aero Sprint"
        >
          <img
            className="w-full h-full object-cover opacity-85 group-hover:opacity-100 transition-opacity"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuAmv-_-3gFCJuHO6tFFdRRqfbLJo4VQEjm6FLf9NUPTMY34P8ApTOUWdOs7w8l9pRLV9CA24kieG2In3koxHxRBG8no-yLI1QwkQL460b-bxbs6pSx5WS8ygOU3mttmVF4GP4xc3ySz97pvr4m7c6GqI6s9G2IYl8rUmqQDl9HNtd9mdo7Iv7Ml6s57-PA2pcacfL0GLSVd32neHaw-ovamBkXtwgMaTA4yGKyECYbgj0Alaoe9Nnd8"
            alt="Aero Sprint"
          />
        </button>

        <div
          className={`absolute -right-2 top-1/2 -translate-y-1/2 w-1 bg-[#bb00fc] rounded-r-full transition-all duration-200 ${
            activeGameId === 'game-aero' ? 'h-8 block' : 'h-2 group-hover:h-5 hidden group-hover:block'
          }`}
        />

        <div className="absolute right-full mr-3 top-1/2 -translate-y-1/2 px-2.5 py-1 bg-[#191c1e] text-white text-xs font-semibold rounded-md shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-50 flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-[#bb00fc]"></span>
          Aero Sprint
        </div>
      </div>

      {/* Add Game Button */}
      <div className="relative group mt-auto mb-3">
        <button
          id="btn-add-server"
          onClick={() => {
            sounds.playClick();
            setActiveTab('games');
          }}
          className="w-12 h-12 rounded-[24px] hover:rounded-[16px] bg-black/5 dark:bg-white/5 border border-dashed border-black/20 dark:border-white/20 flex items-center justify-center transition-all duration-300 hover:border-[#00d2ff] hover:text-[#00677f] dark:hover:text-[#00d2ff] text-black/40 dark:text-white/50 cursor-pointer"
          title="افزودن بازی"
        >
          <span className="material-symbols-outlined text-[22px]">add</span>
        </button>
        <div className="absolute right-full mr-3 top-1/2 -translate-y-1/2 px-2.5 py-1 bg-[#191c1e] text-white text-xs font-semibold rounded-md shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-50">
          افزودن بازی / کاتالوگ
        </div>
      </div>
    </aside>
  );
};
