import React, { useState } from 'react';
import { UserProfile } from '../types';
import { sounds } from '../utils/audio';

interface WalletModalProps {
  user: UserProfile;
  isOpen: boolean;
  onClose: () => void;
  onAddCoins: (amount: number) => void;
  onUpgradeVip: (tier: 'diamond' | 'legend') => void;
}

export const WalletModal: React.FC<WalletModalProps> = ({
  user,
  isOpen,
  onClose,
  onAddCoins,
  onUpgradeVip,
}) => {
  const [claimedDaily, setClaimedDaily] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'balance' | 'shop' | 'history'>('balance');

  if (!isOpen) return null;

  const handleClaimDaily = () => {
    if (claimedDaily) return;
    sounds.playCoin();
    onAddCoins(150);
    setClaimedDaily(true);
  };

  const handleBuyVip = (tier: 'diamond' | 'legend', cost: number) => {
    if (user.dcCoins < cost) return;
    sounds.playCoin();
    onAddCoins(-cost);
    onUpgradeVip(tier);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#f7f9fb] dark:bg-[#191c1e] w-full max-w-lg rounded-3xl border border-white/40 dark:border-white/10 shadow-2xl p-6 flex flex-col gap-5 text-right animate-slide-up select-none">
        {/* Header */}
        <div className="flex justify-between items-center pb-3 border-b border-black/10 dark:border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#bb00fc] to-[#9500ca] flex items-center justify-center text-white shadow-lg">
              <span className="material-symbols-outlined text-2xl">account_balance_wallet</span>
            </div>
            <div>
              <h2 className="font-extrabold text-lg text-[#191c1e] dark:text-white">
                کیف پول DicoCoins (DC)
              </h2>
              <p className="text-xs text-[#3c494e] dark:text-[#bfc8cc]">
                مدیریت دارایی‌ها، جوایز روزانه و نشان‌های VIP
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-black/5 dark:bg-white/10 hover:bg-black/10 text-on-surface flex items-center justify-center transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex bg-black/5 dark:bg-white/5 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab('balance')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'balance'
                ? 'bg-white dark:bg-[#272a2d] text-[#191c1e] dark:text-white shadow-sm'
                : 'text-[#3c494e] dark:text-[#bfc8cc]'
            }`}
          >
            موجودی و شارژ
          </button>
          <button
            onClick={() => setActiveTab('shop')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'shop'
                ? 'bg-white dark:bg-[#272a2d] text-[#191c1e] dark:text-white shadow-sm'
                : 'text-[#3c494e] dark:text-[#bfc8cc]'
            }`}
          >
            فروشگاه VIP
          </button>
        </div>

        {/* Content */}
        {activeTab === 'balance' && (
          <div className="flex flex-col gap-4">
            {/* Balance Card */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-[#00677f] to-[#9500ca] text-white shadow-xl flex justify-between items-center">
              <div>
                <span className="text-xs text-white/80 block">موجودی در دسترس شما:</span>
                <span className="text-3xl font-black mt-1 block">
                  {user.dcCoins.toLocaleString('fa-IR')} DC
                </span>
                <span className="text-[11px] text-[#00d2ff] mt-1 block">
                  سطح عضویت: {user.vipTier === 'diamond' ? '💎 Diamond VIP' : 'عادی'}
                </span>
              </div>
              <span className="material-symbols-outlined text-5xl text-white/40">diamond</span>
            </div>

            {/* Daily Reward Box */}
            <div className="p-4 rounded-2xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 flex justify-between items-center">
              <div>
                <h4 className="font-bold text-sm text-[#191c1e] dark:text-white flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[#f59e0b] text-[18px]">
                    redeem
                  </span>
                  پاداش ورود روزانه
                </h4>
                <p className="text-xs text-[#3c494e] dark:text-[#bfc8cc] mt-0.5">
                  هر ۲۴ ساعت ۱۵۰ DC هدیه رایگان بگیرید!
                </p>
              </div>

              <button
                onClick={handleClaimDaily}
                disabled={claimedDaily}
                className={`px-4 py-2 rounded-xl text-xs font-bold shadow-md transition-all cursor-pointer ${
                  claimedDaily
                    ? 'bg-black/10 dark:bg-white/10 text-[#3c494e]/50 dark:text-[#bfc8cc]/50'
                    : 'bg-gradient-to-r from-[#f59e0b] to-[#ec4899] text-white hover:scale-105'
                }`}
              >
                {claimedDaily ? '✓ دریافت شد' : 'دریافت ۱۵۰ DC'}
              </button>
            </div>

            {/* Free Test Recharge */}
            <div className="flex gap-2">
              <button
                onClick={() => {
                  sounds.playCoin();
                  onAddCoins(500);
                }}
                className="flex-1 py-2.5 rounded-xl bg-black/5 dark:bg-white/10 hover:bg-black/10 text-xs font-bold text-[#00677f] dark:text-[#00d2ff] cursor-pointer"
              >
                + شارژ امتحانی ۵۰۰ DC
              </button>
            </div>
          </div>
        )}

        {activeTab === 'shop' && (
          <div className="flex flex-col gap-3">
            <div className="p-4 rounded-2xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 flex justify-between items-center">
              <div>
                <h4 className="font-bold text-sm text-[#191c1e] dark:text-white flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[#bb00fc] text-[18px]">
                    diamond
                  </span>
                  نشان Diamond VIP در چت
                </h4>
                <p className="text-xs text-[#3c494e] dark:text-[#bfc8cc]">
                  رنگ پیام بنفش و تیک الماس در لیست سرور
                </p>
              </div>
              <button
                onClick={() => handleBuyVip('diamond', 500)}
                disabled={user.vipTier === 'diamond' || user.dcCoins < 500}
                className="px-4 py-2 rounded-xl bg-[#bb00fc] text-white text-xs font-bold shadow hover:opacity-90 disabled:opacity-50 cursor-pointer"
              >
                {user.vipTier === 'diamond' ? 'فعال است' : '۵۰۰ DC'}
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 flex justify-between items-center">
              <div>
                <h4 className="font-bold text-sm text-[#191c1e] dark:text-white flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[#f59e0b] text-[18px]">
                    military_tech
                  </span>
                  نشان Legend Master VIP
                </h4>
                <p className="text-xs text-[#3c494e] dark:text-[#bfc8cc]">
                  قاب طلایی دور آواتار و ورود ویژه به اتاق‌های مسابقه
                </p>
              </div>
              <button
                onClick={() => handleBuyVip('legend', 1000)}
                disabled={user.vipTier === 'legend' || user.dcCoins < 1000}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#f59e0b] to-[#ec4899] text-white text-xs font-bold shadow hover:opacity-90 disabled:opacity-50 cursor-pointer"
              >
                {user.vipTier === 'legend' ? 'فعال است' : '۱,۰۰۰ DC'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
