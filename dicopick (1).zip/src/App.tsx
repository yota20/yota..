import React, { useState, useEffect } from 'react';
import { ActiveTab, ChatMessage, Friend, LiveStream, UserProfile } from './types';
import {
  INITIAL_FRIENDS,
  INITIAL_MESSAGES,
  INITIAL_USER,
  LIVE_STREAMS,
  GAMES_LIST,
  TOURNAMENTS_LIST,
} from './data/mockData';
import { ServerSidebar } from './components/ServerSidebar';
import { NavigationSidebar } from './components/NavigationSidebar';
import { TopNavbar } from './components/TopNavbar';
import { LiveChatSidebar } from './components/LiveChatSidebar';
import { DiscoverView } from './components/DiscoverView';
import { LiveStreamView } from './components/LiveStreamView';
import { GamesView } from './components/GamesView';
import { TournamentsView } from './components/TournamentsView';
import { WalletModal } from './components/WalletModal';
import { ProfileSettingsModal } from './components/ProfileSettingsModal';
import { BottomMobileNavbar } from './components/BottomMobileNavbar';
import { sounds } from './utils/audio';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('discover');
  const [activeGameId, setActiveGameId] = useState<string | null>(null);
  const [selectedStream, setSelectedStream] = useState<LiveStream>(LIVE_STREAMS[0]);

  const [user, setUser] = useState<UserProfile>(INITIAL_USER);
  const [friends, setFriends] = useState<Friend[]>(INITIAL_FRIENDS);
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_MESSAGES);

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  const [isWalletOpen, setIsWalletOpen] = useState<boolean>(false);
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Sync theme with HTML root class
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
    } else {
      document.documentElement.classList.add('light');
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Sync sound settings
  useEffect(() => {
    sounds.enabled = soundEnabled;
  }, [soundEnabled]);

  // Handle User Sending Chat Message
  const handleSendMessage = (text: string) => {
    const now = new Date();
    const timeStr = `${now.getHours()}:${String(now.getMinutes()).padStart(2, '0')}`;

    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      senderName: user.name,
      senderAvatar: user.avatar,
      senderVip: user.vipTier === 'diamond' || user.vipTier === 'legend',
      time: timeStr,
      text,
      reactions: { '👍': 1 },
    };

    setMessages((prev) => [...prev, newMsg]);

    // Simulated community responses after 1.5s
    setTimeout(() => {
      const bots = [
        {
          name: 'CyberKid',
          avatar:
            'https://lh3.googleusercontent.com/aida-public/AB6AXuDUnjPJ4yuoYE7Pr6UTZccTf2tCMz1aPODGAhVb2wVe_u1Z1LU4hdIIlV03a7piXI2YWAtH3KGfsYdeOXf5GIbnxnEdP_idq2C1PHyJLc0uUwShzw8zwIWUsx8BPiNZjhvtkFnZnUdtXvIZ_K-pRaBlnfD19NLcivS1l8QfP9dHcXDLlRr7c69cLedvQTH0X8mSoXRDrSjVUNeFx2z7Jb1SqkCIR8LpG-JVx_vXxeNtC7TljP3IVvzp',
          color: '#00d2ff',
          responses: [
            'ایول! منم پایه‌ام بریم راند بعدی 🚀',
            'رکورد پیست Aero رو چک کردی؟ سرعت ۲۸۰ تا رو زدم!',
            'عالیه، توی لودو حواست به مهره سبز باشه 😎',
          ],
        },
        {
          name: 'Alex Nova',
          avatar:
            'https://lh3.googleusercontent.com/aida-public/AB6AXuDXFdfwzDl_nYbIDUrjoucCHg6iu0BA59WXeS7AvAnyGuJBN13rmrHJvnr_t0QF6rXORW8DO2yJrSp00H82tT8wGqfw-nBq4izuJUqUproaDEdAzzr3UYsOcvwXP2PHCS1_l1zdS2p8edgLSeaz18QFRvs8t1076syvg96wBCQ7of8_escATNPrVSCSTXpBmvgOB1qAkrZ7ED5hL4KotljwdLtJTp2tA5hnCjvwQbAFQHhLE0NFsDp2',
          senderVip: true,
          color: '#bb00fc',
          responses: [
            'دمت گرم! توی استریم هم کامنتت رو دیدم ❤️',
            'بچه‌ها حتماً توی مسابقات هفتگی ثبت‌نام کنید، جایزه‌ش ۵۰k سکه است!',
            'بازی خیلی حساس شد، تاس ۶ لازم دارم 🔥',
          ],
        },
      ];

      const chosenBot = bots[Math.floor(Math.random() * bots.length)];
      const botResponse =
        chosenBot.responses[Math.floor(Math.random() * chosenBot.responses.length)];

      const botMsg: ChatMessage = {
        id: `msg-bot-${Date.now()}`,
        senderName: chosenBot.name,
        senderAvatar: chosenBot.avatar,
        senderVip: chosenBot.senderVip,
        color: chosenBot.color,
        time: `${now.getHours()}:${String(now.getMinutes()).padStart(2, '0')}`,
        text: botResponse,
        reactions: { '🔥': 2, '❤️': 1 },
      };

      sounds.playChatPing();
      setMessages((prev) => [...prev, botMsg]);
    }, 1800);
  };

  // Add / Earn DC coins
  const handleAddCoins = (amount: number) => {
    setUser((prev) => ({
      ...prev,
      dcCoins: Math.max(0, prev.dcCoins + amount),
    }));
  };

  const handleUpgradeVip = (tier: 'diamond' | 'legend') => {
    setUser((prev) => ({
      ...prev,
      vipTier: tier,
    }));
  };

  const handleToggleMic = () => {
    setUser((prev) => ({
      ...prev,
      isMuted: !prev.isMuted,
    }));
  };

  const handleFriendClick = (friend: Friend) => {
    sounds.playClick();
    if (friend.game?.includes('Ludo')) {
      setActiveTab('games');
      setActiveGameId('game-ludo');
    } else if (friend.activity.includes('استریم')) {
      setActiveTab('live');
      setSelectedStream(LIVE_STREAMS[0]);
    } else {
      handleSendMessage(`@${friend.name} سلام! آنلاین هستی بازی کنیم؟`);
    }
  };

  return (
    <div
      dir="rtl"
      className="bg-[#f7f9fb] dark:bg-[#0d1012] text-[#191c1e] dark:text-[#e0e3e5] min-h-screen overflow-hidden font-sans flex relative select-none"
    >
      {/* 1. Discord/Game Server Switcher Bar (Fixed Right: 72px) */}
      <ServerSidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeGameId={activeGameId}
        onSelectGame={(gameId) => {
          setActiveGameId(gameId);
          setActiveTab('games');
        }}
      />

      {/* 2. Inner Navigation Sidebar (Fixed Right: 72px..336px) */}
      <NavigationSidebar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          if (tab !== 'games') setActiveGameId(null);
        }}
        user={user}
        friends={friends}
        onOpenSettings={() => setIsProfileOpen(true)}
        onToggleMic={handleToggleMic}
        onFriendClick={handleFriendClick}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />

      {/* 3. Top Header Bar */}
      <TopNavbar
        activeTab={activeTab}
        user={user}
        onOpenWallet={() => setIsWalletOpen(true)}
        isDarkMode={isDarkMode}
        onToggleTheme={() => setIsDarkMode(!isDarkMode)}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled(!soundEnabled)}
        onOpenMobileMenu={() => setMobileMenuOpen(true)}
      />

      {/* 4. Main Content Area */}
      <main className="flex-1 pt-20 pb-20 md:pb-6 md:mr-[336px] pl-2 md:pl-6 pr-2 md:pr-6 flex gap-6 min-h-screen h-screen overflow-hidden">
        {/* Center Scrollable Content Stream */}
        <div
          className="flex-1 overflow-y-auto pb-12 flex flex-col gap-6 hide-scrollbar px-1"
          style={{ scrollbarWidth: 'none' }}
        >
          {activeTab === 'discover' && (
            <DiscoverView
              streams={LIVE_STREAMS}
              games={GAMES_LIST}
              tournaments={TOURNAMENTS_LIST}
              onSelectStream={(stream) => {
                setSelectedStream(stream);
                setActiveTab('live');
              }}
              onSelectGame={(gameId) => {
                setActiveGameId(gameId);
                setActiveTab('games');
              }}
              onOpenTournaments={() => setActiveTab('tournaments')}
              onQuickPlay={() => {
                setActiveGameId('game-ludo');
                setActiveTab('games');
              }}
            />
          )}

          {activeTab === 'live' && (
            <LiveStreamView
              streams={LIVE_STREAMS}
              selectedStream={selectedStream}
              onSelectStream={setSelectedStream}
              user={user}
              onTipCoins={(amt) => handleAddCoins(-amt)}
            />
          )}

          {activeTab === 'games' && (
            <GamesView
              games={GAMES_LIST}
              activeGameId={activeGameId}
              onSelectGame={setActiveGameId}
              onEarnCoins={handleAddCoins}
            />
          )}

          {activeTab === 'tournaments' && (
            <TournamentsView
              tournaments={TOURNAMENTS_LIST}
              user={user}
              onRegister={(tourId, fee) => handleAddCoins(-fee)}
              onSelectGame={(gameId) => {
                setActiveGameId(gameId);
                setActiveTab('games');
              }}
            />
          )}

          {activeTab === 'wallet' && (
            <div className="flex flex-col gap-6">
              <div className="glass-panel p-8 rounded-3xl border border-white/40 dark:border-white/10 shadow-xl">
                <h1 className="text-2xl font-bold mb-4 text-[#191c1e] dark:text-white flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#bb00fc]">
                    account_balance_wallet
                  </span>
                  مدیریت کیف پول DicoCoins
                </h1>
                <p className="text-sm text-[#3c494e] dark:text-[#bfc8cc] mb-6">
                  موجودی فعلی شما: <strong className="text-gradient-gold text-lg">{user.dcCoins.toLocaleString('fa-IR')} DC</strong>
                </p>
                <div className="flex gap-4">
                  <button
                    onClick={() => setIsWalletOpen(true)}
                    className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#00677f] to-[#9500ca] text-white font-bold text-sm shadow-lg cursor-pointer"
                  >
                    باز کردن داشبورد شارژ و فروشگاه VIP
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 5. Kick/Discord Live Server Chat (Left Column on Large Screens) */}
        <LiveChatSidebar
          messages={messages}
          onSendMessage={handleSendMessage}
          user={user}
        />
      </main>

      {/* 6. Mobile Bottom Navigation Bar */}
      <BottomMobileNavbar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          if (tab !== 'games') setActiveGameId(null);
        }}
        onOpenWallet={() => setIsWalletOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
      />

      {/* 7. Modals */}
      <WalletModal
        user={user}
        isOpen={isWalletOpen}
        onClose={() => setIsWalletOpen(false)}
        onAddCoins={handleAddCoins}
        onUpgradeVip={handleUpgradeVip}
      />

      <ProfileSettingsModal
        user={user}
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        onSaveProfile={(updated) => setUser((prev) => ({ ...prev, ...updated }))}
        isDarkMode={isDarkMode}
        onToggleTheme={() => setIsDarkMode(!isDarkMode)}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled(!soundEnabled)}
      />
    </div>
  );
}
