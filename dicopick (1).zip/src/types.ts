export type ActiveTab = 'discover' | 'live' | 'tournaments' | 'games' | 'wallet' | 'profile';

export interface UserProfile {
  id: string;
  name: string;
  tag: string;
  avatar: string;
  status: 'online' | 'idle' | 'dnd' | 'offline';
  statusText: string;
  isMuted: boolean;
  isDeafened: boolean;
  dcCoins: number;
  vipTier: 'regular' | 'diamond' | 'legend' | 'master';
  bio: string;
}

export interface Friend {
  id: string;
  name: string;
  avatar: string;
  status: 'online' | 'idle' | 'dnd' | 'offline';
  activity: string;
  game?: string;
  isVip?: boolean;
}

export interface ChatMessage {
  id: string;
  senderName: string;
  senderAvatar: string;
  senderVip?: boolean;
  color?: string;
  time: string;
  text: string;
  reactions?: { [emoji: string]: number };
  userReactions?: string[];
  isSystem?: boolean;
}

export interface LiveStream {
  id: string;
  title: string;
  streamerName: string;
  streamerAvatar: string;
  thumbnail: string;
  gameTitle: string;
  category: string;
  language: string;
  viewers: number;
  isLive: boolean;
  gameId: string;
  description?: string;
}

export interface GameItem {
  id: string;
  title: string;
  persianTitle: string;
  thumbnail: string;
  category: string;
  playersOnline: number;
  rating: number;
  description: string;
  colorGradient: string;
  isFeatured?: boolean;
}

export interface Tournament {
  id: string;
  title: string;
  game: string;
  gameThumbnail: string;
  prizePool: string;
  entryFee: number;
  registeredPlayers: number;
  maxPlayers: number;
  startTime: string;
  status: 'upcoming' | 'live' | 'completed';
  rules: string[];
}
